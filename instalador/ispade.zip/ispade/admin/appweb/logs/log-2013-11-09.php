<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-09 11:22:37 --> Config Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:22:37 --> URI Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Router Class Initialized
DEBUG - 2013-11-09 11:22:37 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:22:37 --> Output Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Security Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Input Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:22:37 --> Language Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Loader Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:22:37 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:22:37 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Session Class Initialized
DEBUG - 2013-11-09 11:22:37 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:22:37 --> A session cookie was not found.
DEBUG - 2013-11-09 11:22:38 --> Session garbage collection performed.
DEBUG - 2013-11-09 11:22:38 --> Session routines successfully run
DEBUG - 2013-11-09 11:22:38 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:22:38 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:38 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:22:38 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:38 --> Controller Class Initialized
DEBUG - 2013-11-09 11:22:38 --> Helper loaded: form_helper
DEBUG - 2013-11-09 11:22:38 --> Form Validation Class Initialized
DEBUG - 2013-11-09 11:22:38 --> File loaded: appweb/views/header.php
DEBUG - 2013-11-09 11:22:38 --> File loaded: appweb/views/login.php
DEBUG - 2013-11-09 11:22:38 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:22:38 --> Final output sent to browser
DEBUG - 2013-11-09 11:22:38 --> Total execution time: 0.2839
DEBUG - 2013-11-09 11:22:43 --> Config Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:22:43 --> URI Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Router Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Output Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Security Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Input Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:22:43 --> Language Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Loader Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:22:43 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:22:43 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Session Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:22:43 --> A session cookie was not found.
DEBUG - 2013-11-09 11:22:43 --> Session routines successfully run
DEBUG - 2013-11-09 11:22:43 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:22:43 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Controller Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Helper loaded: form_helper
DEBUG - 2013-11-09 11:22:43 --> Form Validation Class Initialized
DEBUG - 2013-11-09 11:22:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-09 11:22:43 --> XSS Filtering completed
DEBUG - 2013-11-09 11:22:43 --> Unable to find validation rule: min_lengt1
DEBUG - 2013-11-09 11:22:43 --> XSS Filtering completed
DEBUG - 2013-11-09 11:22:44 --> File loaded: appweb/views/redirection.php
DEBUG - 2013-11-09 11:22:44 --> Final output sent to browser
DEBUG - 2013-11-09 11:22:44 --> Total execution time: 0.3415
DEBUG - 2013-11-09 11:22:45 --> Config Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:22:45 --> URI Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Router Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Output Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Security Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Input Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:22:45 --> Language Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Loader Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:22:45 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:22:45 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Session Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:22:45 --> Session routines successfully run
DEBUG - 2013-11-09 11:22:45 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:22:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Controller Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Helper loaded: form_helper
DEBUG - 2013-11-09 11:22:45 --> Form Validation Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Session Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Session routines successfully run
DEBUG - 2013-11-09 11:22:45 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:22:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:22:45 --> Controller Class Initialized
DEBUG - 2013-11-09 11:22:45 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:22:45 --> Severity: Notice  --> Undefined index: nosotros C:\wamp\www\ispade\admin\appweb\views\menu.php 15
ERROR - 2013-11-09 11:22:45 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\admin\appweb\views\menu.php 16
ERROR - 2013-11-09 11:22:45 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\admin\appweb\views\menu.php 17
DEBUG - 2013-11-09 11:22:45 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:22:45 --> File loaded: appweb/views/info_page.php
DEBUG - 2013-11-09 11:22:45 --> File loaded: appweb/views/table.php
DEBUG - 2013-11-09 11:22:45 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:22:45 --> Final output sent to browser
DEBUG - 2013-11-09 11:22:45 --> Total execution time: 0.2140
DEBUG - 2013-11-09 11:27:41 --> Config Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:27:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:27:41 --> URI Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Router Class Initialized
DEBUG - 2013-11-09 11:27:41 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:27:41 --> Output Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Security Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Input Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:27:41 --> Language Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Loader Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:27:41 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:27:41 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Session Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:27:41 --> Session routines successfully run
DEBUG - 2013-11-09 11:27:41 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Model Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Model Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:27:41 --> Model Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Controller Class Initialized
DEBUG - 2013-11-09 11:27:41 --> Helper loaded: form_helper
DEBUG - 2013-11-09 11:27:41 --> Form Validation Class Initialized
DEBUG - 2013-11-09 11:27:41 --> File loaded: appweb/views/header.php
DEBUG - 2013-11-09 11:27:41 --> File loaded: appweb/views/login.php
DEBUG - 2013-11-09 11:27:41 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:27:41 --> Final output sent to browser
DEBUG - 2013-11-09 11:27:41 --> Total execution time: 0.2289
