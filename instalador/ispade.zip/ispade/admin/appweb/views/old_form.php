  
   <div class="container">
      <div class="row wizard">
         <div class="span3">
            <div id="wizard-steps-container">
               <h2>Wizard Title</h2>
   
               <ul id="wizard-steps">
                  <li>
                     <a href="#">Step 1 lorem ipsum</a>
                  </li>
                  <li class="active">
                     <a href="#">Step 2 lorem ipsum</a>
                  </li>
                  <li>
                     <a href="#">Step 3 lorem ipsum</a>
                  </li>
                  <li>
                     <a href="#">Step 4 lorem ipsum</a>
                  </li>
                  <li>
                     <a href="#">Step 5 lorem ipsum</a>
                  </li>
               </ul>
            </div>
         </div>
   
         <div class="span9">
            <section id="wizard-step-content">
               <h2>Step Title</h2>
               <h3>Subtitle</h3>
   
               <form class="form-horizontal">
   
               </form>
   
            </section>
         </div>
      </div>
   </div>