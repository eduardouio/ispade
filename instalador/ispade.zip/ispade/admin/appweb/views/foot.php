<div class="container">
<div class = "hero-unit" style="text-align:center; backgorund-color:#EDF187;">  
  <small style="font-size: 11px;">    
    <p>
      &copy; 2013 Instituto Técnico Superior Para El Desarrollo ISPADE  <a href="http://ispade.edu.ec/web/FrameTotal.html?id=home">Términos De Privacidad</a>
      <br>Sitio Desarrollado Por Eduardo Villota <a href="http://twitter.com/eduardouio" blank="_blank">eduardouio7@gmail.com</a>
    </p>
  </small>
</div>    
<script type="text/javascript" src="<?php print base_url();?>js/jquery.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/modernizr-2.6.2.min.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/google-code-prettify/prettify.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootmetro-panorama.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootmetro-pivot.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootmetro-charms.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/holder.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-scrollspy.js"></script>  
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-button.js"></script>  
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-carousel.js"></script> 
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-modal.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/demo.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/jquery.mousewheel.min.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/jquery.touchSwipe.min.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/wysihtml5-0.3.0.js"></script>
<script type="text/javascript" src="<?php print base_url();?>js/bootstrap-wysihtml5.js"></script>
<script type="text/javascript">
$('#myModal2').modal();
</script>
<script>
	$('.textarea').wysihtml5();
</script>

<script type="text/javascript" charset="utf-8">
	$(prettyPrint);
</script>
</div>
</body>
</html>