<div style="float:right;width: 50%;height50%"> <img src="<?php print base_url();?>img/sitio/buzon.png"></div>
<div class = "alert alert-success">
	<h3>Formulario Enviado!...</h3><br>
	Hemos recibido su informacion con fecha <?php print date("Y-m-d H:i:s"); ?>, gracias por escribirnos <br>
</div>
</div>
</div>
</div> <!-- ./Contenedor Fluido-->
</div> <!-- ./ Cuerpo de contenidos-->
<!--/Presentacion de contenidos-->
