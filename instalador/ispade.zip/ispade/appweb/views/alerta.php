<div class = "alert alert-danger">
	<h3>Lo Sentimos...</h3><br>
	<?php print validation_errors();?>
	Tenemos problemas para validar la informacion los valores son muy cortos o no ingreso un dato.<br>
	Favor Revise los campos e intente nuevamente...
</div>
