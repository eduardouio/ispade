<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-21 12:54:38 --> Config Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:54:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:54:38 --> URI Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Router Class Initialized
DEBUG - 2013-09-21 12:54:38 --> No URI present. Default controller set.
DEBUG - 2013-09-21 12:54:38 --> Output Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Security Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Input Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:54:38 --> Language Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Loader Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 12:54:38 --> Helper loaded: url_helper
DEBUG - 2013-09-21 12:54:38 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Session Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Helper loaded: string_helper
DEBUG - 2013-09-21 12:54:38 --> A session cookie was not found.
DEBUG - 2013-09-21 12:54:38 --> Session routines successfully run
DEBUG - 2013-09-21 12:54:38 --> Pagination Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Controller Class Initialized
DEBUG - 2013-09-21 12:54:38 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 12:54:38 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 12:54:38 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 12:54:38 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 12:54:38 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 12:54:38 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 12:54:38 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-21 12:54:38 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-21 12:54:38 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 12:54:38 --> Final output sent to browser
DEBUG - 2013-09-21 12:54:38 --> Total execution time: 0.1981
DEBUG - 2013-09-21 18:14:02 --> Config Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:14:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:14:02 --> URI Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Router Class Initialized
DEBUG - 2013-09-21 18:14:02 --> No URI present. Default controller set.
DEBUG - 2013-09-21 18:14:02 --> Output Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Security Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Input Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:14:02 --> Language Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Loader Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:14:02 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:14:02 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Session Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:14:02 --> A session cookie was not found.
DEBUG - 2013-09-21 18:14:02 --> Session routines successfully run
DEBUG - 2013-09-21 18:14:02 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Model Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Model Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:14:02 --> Model Class Initialized
DEBUG - 2013-09-21 18:14:02 --> Controller Class Initialized
DEBUG - 2013-09-21 18:14:02 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:14:02 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:14:02 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:14:02 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:14:02 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:14:02 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:14:02 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-21 18:14:02 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-21 18:14:02 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:14:02 --> Final output sent to browser
DEBUG - 2013-09-21 18:14:02 --> Total execution time: 0.1212
DEBUG - 2013-09-21 18:15:31 --> Config Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:15:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:15:31 --> URI Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Router Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Output Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Security Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Input Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:15:31 --> Language Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Loader Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:15:31 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:15:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Session Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:15:31 --> Session routines successfully run
DEBUG - 2013-09-21 18:15:31 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:15:31 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:31 --> Controller Class Initialized
DEBUG - 2013-09-21 18:15:31 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:15:31 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-21 18:15:31 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:15:31 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:15:31 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:15:31 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:15:31 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-21 18:15:31 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-21 18:15:31 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:15:31 --> Final output sent to browser
DEBUG - 2013-09-21 18:15:31 --> Total execution time: 0.1100
DEBUG - 2013-09-21 18:15:36 --> Config Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:15:36 --> URI Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Router Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Output Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Security Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Input Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:15:36 --> Language Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Loader Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:15:36 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:15:36 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Session Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:15:36 --> Session routines successfully run
DEBUG - 2013-09-21 18:15:36 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:15:36 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:36 --> Controller Class Initialized
DEBUG - 2013-09-21 18:15:36 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:15:36 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-21 18:15:36 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:15:36 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:15:36 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:15:36 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:15:36 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-21 18:15:36 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-21 18:15:36 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:15:36 --> Final output sent to browser
DEBUG - 2013-09-21 18:15:36 --> Total execution time: 0.0271
DEBUG - 2013-09-21 18:15:43 --> Config Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:15:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:15:43 --> URI Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Router Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Output Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Security Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Input Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:15:43 --> Language Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Loader Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:15:43 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:15:43 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Session Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:15:43 --> Session routines successfully run
DEBUG - 2013-09-21 18:15:43 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:15:43 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:43 --> Controller Class Initialized
DEBUG - 2013-09-21 18:15:43 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-21 18:15:43 --> Final output sent to browser
DEBUG - 2013-09-21 18:15:43 --> Total execution time: 0.0905
DEBUG - 2013-09-21 18:15:53 --> Config Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:15:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:15:53 --> URI Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Router Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Output Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Security Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Input Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:15:53 --> Language Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Loader Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:15:53 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:15:53 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Session Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:15:53 --> Session routines successfully run
DEBUG - 2013-09-21 18:15:53 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:15:53 --> Model Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Controller Class Initialized
DEBUG - 2013-09-21 18:15:53 --> Helper loaded: email_helper
DEBUG - 2013-09-21 18:15:53 --> Helper loaded: form_helper
DEBUG - 2013-09-21 18:15:53 --> Form Validation Class Initialized
DEBUG - 2013-09-21 18:15:53 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:15:53 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-21 18:15:53 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:15:53 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:15:53 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-21 18:15:53 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:15:53 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-21 18:15:53 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-21 18:15:53 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:15:53 --> Final output sent to browser
DEBUG - 2013-09-21 18:15:53 --> Total execution time: 0.0789
DEBUG - 2013-09-21 18:16:16 --> Config Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:16:16 --> URI Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Router Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Output Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Security Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Input Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:16:16 --> Language Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Loader Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:16:16 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:16:16 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Session Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:16:16 --> Session routines successfully run
DEBUG - 2013-09-21 18:16:16 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Model Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Model Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:16:16 --> Model Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Controller Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Helper loaded: email_helper
DEBUG - 2013-09-21 18:16:16 --> Helper loaded: form_helper
DEBUG - 2013-09-21 18:16:16 --> Form Validation Class Initialized
DEBUG - 2013-09-21 18:16:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-21 18:16:16 --> XSS Filtering completed
DEBUG - 2013-09-21 18:16:16 --> XSS Filtering completed
DEBUG - 2013-09-21 18:16:16 --> XSS Filtering completed
DEBUG - 2013-09-21 18:16:16 --> XSS Filtering completed
DEBUG - 2013-09-21 18:16:16 --> XSS Filtering completed
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:16:16 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-21 18:16:16 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:16:16 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:16:16 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/alerta.php
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-21 18:16:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:16:16 --> Final output sent to browser
DEBUG - 2013-09-21 18:16:16 --> Total execution time: 0.0832
DEBUG - 2013-09-21 18:31:14 --> Config Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:31:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:31:14 --> URI Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Router Class Initialized
DEBUG - 2013-09-21 18:31:14 --> No URI present. Default controller set.
DEBUG - 2013-09-21 18:31:14 --> Output Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Security Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Input Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:31:14 --> Language Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Loader Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:31:14 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:31:14 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Session Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:31:14 --> Session routines successfully run
DEBUG - 2013-09-21 18:31:14 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:31:14 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:14 --> Controller Class Initialized
DEBUG - 2013-09-21 18:31:14 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:31:14 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:31:14 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:31:14 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:31:14 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:31:14 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:31:14 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-21 18:31:14 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-21 18:31:14 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:31:14 --> Final output sent to browser
DEBUG - 2013-09-21 18:31:14 --> Total execution time: 0.0461
DEBUG - 2013-09-21 18:31:19 --> Config Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:31:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:31:19 --> URI Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Router Class Initialized
DEBUG - 2013-09-21 18:31:19 --> No URI present. Default controller set.
DEBUG - 2013-09-21 18:31:19 --> Output Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Security Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Input Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:31:19 --> Language Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Loader Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:31:19 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:31:19 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Session Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:31:19 --> A session cookie was not found.
DEBUG - 2013-09-21 18:31:19 --> Session routines successfully run
DEBUG - 2013-09-21 18:31:19 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:31:19 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:19 --> Controller Class Initialized
DEBUG - 2013-09-21 18:31:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:31:19 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-21 18:31:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:31:19 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:31:19 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:31:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:31:19 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-21 18:31:19 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-21 18:31:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:31:19 --> Final output sent to browser
DEBUG - 2013-09-21 18:31:19 --> Total execution time: 0.0368
DEBUG - 2013-09-21 18:31:22 --> Config Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 18:31:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 18:31:22 --> URI Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Router Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Output Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Security Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Input Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 18:31:22 --> Language Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Loader Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-21 18:31:22 --> Helper loaded: url_helper
DEBUG - 2013-09-21 18:31:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Session Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Helper loaded: string_helper
DEBUG - 2013-09-21 18:31:22 --> Session routines successfully run
DEBUG - 2013-09-21 18:31:22 --> Pagination Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-21 18:31:22 --> Model Class Initialized
DEBUG - 2013-09-21 18:31:22 --> Controller Class Initialized
DEBUG - 2013-09-21 18:31:22 --> File loaded: appweb/views/header.php
ERROR - 2013-09-21 18:31:22 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-21 18:31:22 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-21 18:31:22 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-21 18:31:22 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-21 18:31:22 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-21 18:31:22 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-21 18:31:22 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-21 18:31:22 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-21 18:31:22 --> Final output sent to browser
DEBUG - 2013-09-21 18:31:22 --> Total execution time: 0.0529
