<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-09 11:19:00 --> Config Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:19:00 --> URI Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Router Class Initialized
DEBUG - 2013-11-09 11:19:00 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:19:00 --> Output Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Security Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Input Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:19:00 --> Language Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Loader Class Initialized
DEBUG - 2013-11-09 11:19:00 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:19:00 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:19:00 --> Database Driver Class Initialized
ERROR - 2013-11-09 11:19:00 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\ispade\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-11-09 11:19:00 --> Unable to connect to the database
DEBUG - 2013-11-09 11:19:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-09 11:22:19 --> Config Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:22:19 --> URI Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Router Class Initialized
DEBUG - 2013-11-09 11:22:19 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:22:19 --> Output Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Security Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Input Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:22:19 --> Language Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Loader Class Initialized
DEBUG - 2013-11-09 11:22:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:22:19 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:22:19 --> Database Driver Class Initialized
ERROR - 2013-11-09 11:22:19 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\ispade\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-11-09 11:22:19 --> Unable to connect to the database
DEBUG - 2013-11-09 11:22:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-09 11:22:34 --> Config Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:22:34 --> URI Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Router Class Initialized
DEBUG - 2013-11-09 11:22:34 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:22:34 --> Output Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Security Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Input Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:22:34 --> Language Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Loader Class Initialized
DEBUG - 2013-11-09 11:22:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:22:34 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:22:34 --> Database Driver Class Initialized
ERROR - 2013-11-09 11:22:34 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) C:\wamp\www\ispade\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-11-09 11:22:34 --> Unable to connect to the database
DEBUG - 2013-11-09 11:22:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-09 11:23:45 --> Config Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:23:45 --> URI Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Router Class Initialized
DEBUG - 2013-11-09 11:23:45 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:23:45 --> Output Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Security Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Input Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:23:45 --> Language Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Loader Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:23:45 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:23:45 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Session Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:23:45 --> Session routines successfully run
DEBUG - 2013-11-09 11:23:45 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:23:45 --> Model Class Initialized
DEBUG - 2013-11-09 11:23:45 --> Controller Class Initialized
DEBUG - 2013-11-09 11:23:45 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:23:45 --> Severity: Notice  --> Undefined index: nosotros C:\wamp\www\ispade\appweb\views\menu.php 31
ERROR - 2013-11-09 11:23:45 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\appweb\views\menu.php 32
ERROR - 2013-11-09 11:23:45 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\appweb\views\menu.php 33
ERROR - 2013-11-09 11:23:45 --> Severity: Notice  --> Undefined index: contactos C:\wamp\www\ispade\appweb\views\menu.php 34
DEBUG - 2013-11-09 11:23:45 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:23:45 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-11-09 11:23:45 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-11-09 11:23:45 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:23:45 --> Final output sent to browser
DEBUG - 2013-11-09 11:23:45 --> Total execution time: 0.1942
DEBUG - 2013-11-09 11:25:32 --> Config Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:25:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:25:32 --> URI Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Router Class Initialized
DEBUG - 2013-11-09 11:25:32 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:25:32 --> Output Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Security Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Input Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:25:32 --> Language Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Loader Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:25:32 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:25:32 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Session Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:25:32 --> Session routines successfully run
DEBUG - 2013-11-09 11:25:32 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:25:32 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:32 --> Controller Class Initialized
DEBUG - 2013-11-09 11:25:32 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:25:32 --> Severity: Notice  --> Undefined index: nosotros C:\wamp\www\ispade\appweb\views\menu.php 31
ERROR - 2013-11-09 11:25:32 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\appweb\views\menu.php 32
ERROR - 2013-11-09 11:25:32 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\appweb\views\menu.php 33
ERROR - 2013-11-09 11:25:32 --> Severity: Notice  --> Undefined index: contactos C:\wamp\www\ispade\appweb\views\menu.php 34
DEBUG - 2013-11-09 11:25:32 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:25:32 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-11-09 11:25:32 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-11-09 11:25:32 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:25:32 --> Final output sent to browser
DEBUG - 2013-11-09 11:25:32 --> Total execution time: 0.1456
DEBUG - 2013-11-09 11:25:37 --> Config Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:25:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:25:37 --> URI Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Router Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Output Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Security Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Input Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:25:37 --> Language Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Loader Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:25:37 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:25:37 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Session Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:25:37 --> Session routines successfully run
DEBUG - 2013-11-09 11:25:37 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:25:37 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:37 --> Controller Class Initialized
DEBUG - 2013-11-09 11:25:37 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:25:37 --> Severity: Notice  --> Undefined index: home C:\wamp\www\ispade\appweb\views\menu.php 30
ERROR - 2013-11-09 11:25:37 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\appweb\views\menu.php 32
ERROR - 2013-11-09 11:25:37 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\appweb\views\menu.php 33
ERROR - 2013-11-09 11:25:37 --> Severity: Notice  --> Undefined index: contactos C:\wamp\www\ispade\appweb\views\menu.php 34
DEBUG - 2013-11-09 11:25:37 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:25:37 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-11-09 11:25:37 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-11-09 11:25:37 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:25:37 --> Final output sent to browser
DEBUG - 2013-11-09 11:25:37 --> Total execution time: 0.2268
DEBUG - 2013-11-09 11:25:39 --> Config Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:25:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:25:39 --> URI Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Router Class Initialized
DEBUG - 2013-11-09 11:25:39 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:25:39 --> Output Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Security Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Input Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:25:39 --> Language Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Loader Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:25:39 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:25:39 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Session Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:25:39 --> Session routines successfully run
DEBUG - 2013-11-09 11:25:39 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:25:39 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:39 --> Controller Class Initialized
DEBUG - 2013-11-09 11:25:39 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:25:39 --> Severity: Notice  --> Undefined index: nosotros C:\wamp\www\ispade\appweb\views\menu.php 31
ERROR - 2013-11-09 11:25:39 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\appweb\views\menu.php 32
ERROR - 2013-11-09 11:25:39 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\appweb\views\menu.php 33
ERROR - 2013-11-09 11:25:39 --> Severity: Notice  --> Undefined index: contactos C:\wamp\www\ispade\appweb\views\menu.php 34
DEBUG - 2013-11-09 11:25:39 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:25:39 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-11-09 11:25:39 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-11-09 11:25:39 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:25:39 --> Final output sent to browser
DEBUG - 2013-11-09 11:25:39 --> Total execution time: 0.1815
DEBUG - 2013-11-09 11:25:52 --> Config Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Hooks Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Utf8 Class Initialized
DEBUG - 2013-11-09 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-09 11:25:52 --> URI Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Router Class Initialized
DEBUG - 2013-11-09 11:25:52 --> No URI present. Default controller set.
DEBUG - 2013-11-09 11:25:52 --> Output Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Security Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Input Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-09 11:25:52 --> Language Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Loader Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-11-09 11:25:52 --> Helper loaded: url_helper
DEBUG - 2013-11-09 11:25:52 --> Database Driver Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Session Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Helper loaded: string_helper
DEBUG - 2013-11-09 11:25:52 --> Session routines successfully run
DEBUG - 2013-11-09 11:25:52 --> Pagination Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-11-09 11:25:52 --> Model Class Initialized
DEBUG - 2013-11-09 11:25:52 --> Controller Class Initialized
DEBUG - 2013-11-09 11:25:52 --> File loaded: appweb/views/header.php
ERROR - 2013-11-09 11:25:52 --> Severity: Notice  --> Undefined index: nosotros C:\wamp\www\ispade\appweb\views\menu.php 31
ERROR - 2013-11-09 11:25:52 --> Severity: Notice  --> Undefined index: noticias C:\wamp\www\ispade\appweb\views\menu.php 32
ERROR - 2013-11-09 11:25:52 --> Severity: Notice  --> Undefined index: servicios C:\wamp\www\ispade\appweb\views\menu.php 33
ERROR - 2013-11-09 11:25:52 --> Severity: Notice  --> Undefined index: contactos C:\wamp\www\ispade\appweb\views\menu.php 34
DEBUG - 2013-11-09 11:25:52 --> File loaded: appweb/views/menu.php
DEBUG - 2013-11-09 11:25:52 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-11-09 11:25:52 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-11-09 11:25:52 --> File loaded: appweb/views/foot.php
DEBUG - 2013-11-09 11:25:52 --> Final output sent to browser
DEBUG - 2013-11-09 11:25:52 --> Total execution time: 0.1511
