<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-24 09:51:28 --> Config Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:51:28 --> URI Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Router Class Initialized
DEBUG - 2013-09-24 09:51:28 --> No URI present. Default controller set.
DEBUG - 2013-09-24 09:51:28 --> Output Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Security Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Input Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:51:28 --> Language Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Loader Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:51:28 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:51:28 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Session Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:51:28 --> A session cookie was not found.
DEBUG - 2013-09-24 09:51:28 --> Session routines successfully run
DEBUG - 2013-09-24 09:51:28 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Model Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Model Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:51:28 --> Model Class Initialized
DEBUG - 2013-09-24 09:51:28 --> Controller Class Initialized
DEBUG - 2013-09-24 09:51:28 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:51:28 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:51:28 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-24 09:51:28 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:51:28 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:51:28 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:51:28 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-24 09:51:28 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-24 09:51:28 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:51:28 --> Final output sent to browser
DEBUG - 2013-09-24 09:51:28 --> Total execution time: 0.1319
DEBUG - 2013-09-24 09:52:12 --> Config Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:52:12 --> URI Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Router Class Initialized
DEBUG - 2013-09-24 09:52:12 --> No URI present. Default controller set.
DEBUG - 2013-09-24 09:52:12 --> Output Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Security Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Input Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:52:12 --> Language Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Loader Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:52:12 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:52:12 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Session Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:52:12 --> A session cookie was not found.
DEBUG - 2013-09-24 09:52:12 --> Session routines successfully run
DEBUG - 2013-09-24 09:52:12 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Model Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Model Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:52:12 --> Model Class Initialized
DEBUG - 2013-09-24 09:52:12 --> Controller Class Initialized
DEBUG - 2013-09-24 09:52:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:52:12 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:52:12 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-24 09:52:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:52:12 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:52:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:52:12 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-24 09:52:12 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-24 09:52:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:52:12 --> Final output sent to browser
DEBUG - 2013-09-24 09:52:12 --> Total execution time: 0.0510
DEBUG - 2013-09-24 09:54:42 --> Config Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:54:42 --> URI Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Router Class Initialized
DEBUG - 2013-09-24 09:54:42 --> No URI present. Default controller set.
DEBUG - 2013-09-24 09:54:42 --> Output Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Security Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Input Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:54:42 --> Language Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Loader Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:54:42 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:54:42 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Session Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:54:42 --> A session cookie was not found.
DEBUG - 2013-09-24 09:54:42 --> Session routines successfully run
DEBUG - 2013-09-24 09:54:42 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:54:42 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:42 --> Controller Class Initialized
DEBUG - 2013-09-24 09:54:42 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:54:42 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:54:42 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-24 09:54:42 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:54:42 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:54:42 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:54:42 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-24 09:54:42 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-24 09:54:42 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:54:42 --> Final output sent to browser
DEBUG - 2013-09-24 09:54:42 --> Total execution time: 0.0244
DEBUG - 2013-09-24 09:54:48 --> Config Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:54:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:54:48 --> URI Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Router Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Output Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Security Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Input Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:54:48 --> Language Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Loader Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:54:48 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:54:48 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Session Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:54:48 --> Session routines successfully run
DEBUG - 2013-09-24 09:54:48 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:54:48 --> Model Class Initialized
DEBUG - 2013-09-24 09:54:48 --> Controller Class Initialized
DEBUG - 2013-09-24 09:54:48 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:54:48 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-24 09:54:48 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:54:48 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:54:48 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:54:48 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:54:48 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-24 09:54:48 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-24 09:54:48 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:54:48 --> Final output sent to browser
DEBUG - 2013-09-24 09:54:48 --> Total execution time: 0.0856
DEBUG - 2013-09-24 09:55:13 --> Config Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:55:13 --> URI Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Router Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Output Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Security Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Input Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:55:13 --> Language Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Loader Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:55:13 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:55:13 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Session Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:55:13 --> Session routines successfully run
DEBUG - 2013-09-24 09:55:13 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:55:13 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:13 --> Controller Class Initialized
DEBUG - 2013-09-24 09:55:13 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:55:13 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-24 09:55:13 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:55:13 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:55:13 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:55:13 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:55:13 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-24 09:55:13 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-24 09:55:13 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:55:13 --> Final output sent to browser
DEBUG - 2013-09-24 09:55:13 --> Total execution time: 0.0567
DEBUG - 2013-09-24 09:55:23 --> Config Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:55:23 --> URI Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Router Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Output Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Security Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Input Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:55:23 --> Language Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Loader Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:55:23 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:55:23 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Session Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:55:23 --> Session routines successfully run
DEBUG - 2013-09-24 09:55:23 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:55:23 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:23 --> Controller Class Initialized
DEBUG - 2013-09-24 09:55:23 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-24 09:55:23 --> Final output sent to browser
DEBUG - 2013-09-24 09:55:23 --> Total execution time: 0.1766
DEBUG - 2013-09-24 09:55:32 --> Config Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:55:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:55:32 --> URI Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Router Class Initialized
DEBUG - 2013-09-24 09:55:32 --> No URI present. Default controller set.
DEBUG - 2013-09-24 09:55:32 --> Output Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Security Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Input Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:55:32 --> Language Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Loader Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:55:32 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:55:32 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Session Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:55:32 --> Session routines successfully run
DEBUG - 2013-09-24 09:55:32 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:55:32 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:32 --> Controller Class Initialized
DEBUG - 2013-09-24 09:55:32 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:55:32 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:55:32 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-24 09:55:32 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:55:32 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:55:32 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:55:32 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-24 09:55:32 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-24 09:55:32 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:55:32 --> Final output sent to browser
DEBUG - 2013-09-24 09:55:32 --> Total execution time: 0.0269
DEBUG - 2013-09-24 09:55:38 --> Config Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Hooks Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Utf8 Class Initialized
DEBUG - 2013-09-24 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-24 09:55:38 --> URI Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Router Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Output Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Security Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Input Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-24 09:55:38 --> Language Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Loader Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-24 09:55:38 --> Helper loaded: url_helper
DEBUG - 2013-09-24 09:55:38 --> Database Driver Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Session Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Helper loaded: string_helper
DEBUG - 2013-09-24 09:55:38 --> Session routines successfully run
DEBUG - 2013-09-24 09:55:38 --> Pagination Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-24 09:55:38 --> Model Class Initialized
DEBUG - 2013-09-24 09:55:38 --> Controller Class Initialized
DEBUG - 2013-09-24 09:55:38 --> File loaded: appweb/views/header.php
ERROR - 2013-09-24 09:55:38 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-24 09:55:38 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-24 09:55:38 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-24 09:55:38 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-24 09:55:38 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-24 09:55:38 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-24 09:55:38 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-24 09:55:38 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-24 09:55:38 --> Final output sent to browser
DEBUG - 2013-09-24 09:55:38 --> Total execution time: 0.0539
