<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-18 17:53:31 --> Config Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:53:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:53:31 --> URI Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Router Class Initialized
DEBUG - 2013-09-18 17:53:31 --> No URI present. Default controller set.
DEBUG - 2013-09-18 17:53:31 --> Output Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Security Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Input Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:53:31 --> Language Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Loader Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:53:31 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:53:31 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Session Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:53:31 --> Session routines successfully run
DEBUG - 2013-09-18 17:53:31 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:53:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:31 --> Controller Class Initialized
DEBUG - 2013-09-18 17:53:31 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:53:31 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:53:31 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:53:31 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:53:31 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:53:31 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:53:31 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 17:53:31 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 17:53:31 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:53:31 --> Final output sent to browser
DEBUG - 2013-09-18 17:53:31 --> Total execution time: 0.0283
DEBUG - 2013-09-18 17:53:34 --> Config Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:53:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:53:34 --> URI Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Router Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Output Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Security Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Input Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:53:34 --> Language Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Loader Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:53:34 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:53:34 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Session Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:53:34 --> Session routines successfully run
DEBUG - 2013-09-18 17:53:34 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:53:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:34 --> Controller Class Initialized
DEBUG - 2013-09-18 17:53:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:53:34 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:53:34 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:53:34 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:53:34 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:53:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:53:34 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:53:34 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:53:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:53:34 --> Final output sent to browser
DEBUG - 2013-09-18 17:53:34 --> Total execution time: 0.0391
DEBUG - 2013-09-18 17:53:36 --> Config Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:53:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:53:36 --> URI Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Router Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Output Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Security Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Input Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:53:36 --> Language Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Loader Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:53:36 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:53:36 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Session Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:53:36 --> Session routines successfully run
DEBUG - 2013-09-18 17:53:36 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:53:36 --> Model Class Initialized
DEBUG - 2013-09-18 17:53:36 --> Controller Class Initialized
DEBUG - 2013-09-18 17:53:36 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:53:36 --> Final output sent to browser
DEBUG - 2013-09-18 17:53:36 --> Total execution time: 0.0924
DEBUG - 2013-09-18 17:54:34 --> Config Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:54:34 --> URI Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Router Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Output Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Security Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Input Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:54:34 --> Language Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Loader Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:54:34 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:54:34 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Session Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:54:34 --> Session routines successfully run
DEBUG - 2013-09-18 17:54:34 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:54:34 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:34 --> Controller Class Initialized
DEBUG - 2013-09-18 17:54:34 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:54:34 --> Final output sent to browser
DEBUG - 2013-09-18 17:54:34 --> Total execution time: 0.1357
DEBUG - 2013-09-18 17:54:38 --> Config Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:54:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:54:38 --> URI Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Router Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Output Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Security Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Input Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:54:38 --> Language Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Loader Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:54:38 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:54:38 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Session Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:54:38 --> Session routines successfully run
DEBUG - 2013-09-18 17:54:38 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:54:38 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:38 --> Controller Class Initialized
DEBUG - 2013-09-18 17:54:38 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:54:38 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:54:38 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:54:38 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:54:38 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:54:38 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:54:38 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:54:51 --> Config Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:54:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:54:51 --> URI Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Router Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Output Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Security Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Input Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:54:51 --> Language Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Loader Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:54:51 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:54:51 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Session Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:54:51 --> Session routines successfully run
DEBUG - 2013-09-18 17:54:51 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:54:51 --> Model Class Initialized
DEBUG - 2013-09-18 17:54:51 --> Controller Class Initialized
DEBUG - 2013-09-18 17:54:51 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:54:51 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:54:51 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:54:51 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:54:51 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:54:51 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:54:51 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:54:51 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:54:51 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:54:51 --> Final output sent to browser
DEBUG - 2013-09-18 17:54:51 --> Total execution time: 0.0333
DEBUG - 2013-09-18 17:55:15 --> Config Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:55:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:55:15 --> URI Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Router Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Output Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Security Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Input Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:55:15 --> Language Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Loader Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:55:15 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:55:15 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Session Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:55:15 --> Session routines successfully run
DEBUG - 2013-09-18 17:55:15 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:55:15 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:15 --> Controller Class Initialized
DEBUG - 2013-09-18 17:55:15 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:55:15 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:55:15 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:55:15 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:55:15 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:55:15 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:55:15 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:55:15 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:55:15 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:55:15 --> Final output sent to browser
DEBUG - 2013-09-18 17:55:15 --> Total execution time: 0.0381
DEBUG - 2013-09-18 17:55:17 --> Config Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:55:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:55:17 --> URI Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Router Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Output Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Security Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Input Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:55:17 --> Language Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Loader Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:55:17 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:55:17 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Session Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:55:17 --> Session routines successfully run
DEBUG - 2013-09-18 17:55:17 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:55:17 --> Model Class Initialized
DEBUG - 2013-09-18 17:55:17 --> Controller Class Initialized
DEBUG - 2013-09-18 17:55:17 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:55:17 --> Final output sent to browser
DEBUG - 2013-09-18 17:55:17 --> Total execution time: 0.0965
DEBUG - 2013-09-18 17:56:28 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:28 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:28 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:28 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:28 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:28 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:28 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:28 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:28 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:28 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:56:28 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:28 --> Total execution time: 0.1158
DEBUG - 2013-09-18 17:56:31 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:31 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:31 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:31 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:31 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:31 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:31 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:31 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:31 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:31 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:56:31 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:31 --> Total execution time: 0.0986
DEBUG - 2013-09-18 17:56:37 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:37 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:37 --> No URI present. Default controller set.
DEBUG - 2013-09-18 17:56:37 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:37 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:37 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:37 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:37 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:37 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:37 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:37 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:37 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:37 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:37 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:56:37 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:37 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:37 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:37 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 17:56:37 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 17:56:37 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:37 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:37 --> Total execution time: 0.0335
DEBUG - 2013-09-18 17:56:39 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:39 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:39 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:39 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:39 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:39 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:39 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:39 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:39 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:39 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:39 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:39 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:39 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:39 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:39 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:39 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:39 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:56:39 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:39 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:39 --> Total execution time: 0.0379
DEBUG - 2013-09-18 17:56:41 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:41 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:41 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:41 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:41 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:41 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:41 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:41 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:41 --> Helper loaded: email_helper
DEBUG - 2013-09-18 17:56:41 --> Helper loaded: form_helper
DEBUG - 2013-09-18 17:56:41 --> Form Validation Class Initialized
DEBUG - 2013-09-18 17:56:41 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:41 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:41 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:41 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:56:41 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
DEBUG - 2013-09-18 17:56:41 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:41 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:41 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-18 17:56:41 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:41 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:41 --> Total execution time: 0.0334
DEBUG - 2013-09-18 17:56:43 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:43 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:43 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:43 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:43 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:43 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:43 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:43 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:43 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:43 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:43 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:43 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:43 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:56:43 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:43 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:43 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:43 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:56:43 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:43 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:43 --> Total execution time: 0.0273
DEBUG - 2013-09-18 17:56:44 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:44 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:44 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:44 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:44 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:44 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:44 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:44 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:44 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:44 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:44 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:44 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:44 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:44 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:44 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:44 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:44 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:56:44 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:44 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:44 --> Total execution time: 0.0333
DEBUG - 2013-09-18 17:56:45 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:45 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:45 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:45 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:45 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:45 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:45 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:45 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:45 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:45 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:56:45 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:45 --> Total execution time: 0.0982
DEBUG - 2013-09-18 17:56:48 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:48 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:48 --> No URI present. Default controller set.
DEBUG - 2013-09-18 17:56:48 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:48 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:48 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:48 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:48 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:48 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:48 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:48 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:48 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:48 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:48 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:56:48 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:48 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:48 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:48 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 17:56:48 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 17:56:48 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:48 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:48 --> Total execution time: 0.0259
DEBUG - 2013-09-18 17:56:49 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:49 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:49 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:49 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:49 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:49 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:49 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:49 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:49 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:49 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:49 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:49 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 17:56:49 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:49 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:49 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:49 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:49 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:56:49 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:49 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:49 --> Total execution time: 0.0274
DEBUG - 2013-09-18 17:56:50 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:50 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:50 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:50 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:50 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:50 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:50 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:50 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:50 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:50 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:56:50 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:50 --> Total execution time: 0.2022
DEBUG - 2013-09-18 17:56:53 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:53 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:53 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:53 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:53 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:53 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:53 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:53 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:53 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:53 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 17:56:53 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 17:56:53 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 17:56:53 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 17:56:53 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 17:56:53 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 17:56:53 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 17:56:53 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 17:56:53 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 17:56:53 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:53 --> Total execution time: 0.0271
DEBUG - 2013-09-18 17:56:55 --> Config Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Hooks Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Utf8 Class Initialized
DEBUG - 2013-09-18 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 17:56:55 --> URI Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Router Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Output Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Security Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Input Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 17:56:55 --> Language Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Loader Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 17:56:55 --> Helper loaded: url_helper
DEBUG - 2013-09-18 17:56:55 --> Database Driver Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Session Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Helper loaded: string_helper
DEBUG - 2013-09-18 17:56:55 --> Session routines successfully run
DEBUG - 2013-09-18 17:56:55 --> Pagination Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 17:56:55 --> Model Class Initialized
DEBUG - 2013-09-18 17:56:55 --> Controller Class Initialized
DEBUG - 2013-09-18 17:56:55 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 17:56:55 --> Final output sent to browser
DEBUG - 2013-09-18 17:56:55 --> Total execution time: 0.1020
DEBUG - 2013-09-18 18:09:03 --> Config Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:09:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:09:03 --> URI Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Router Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Output Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Security Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Input Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:09:03 --> Language Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Loader Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:09:03 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:09:03 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Session Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:09:03 --> Session routines successfully run
DEBUG - 2013-09-18 18:09:03 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:09:03 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:03 --> Controller Class Initialized
ERROR - 2013-09-18 18:09:03 --> 404 Page Not Found --> home/asdasd
DEBUG - 2013-09-18 18:09:10 --> Config Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:09:10 --> URI Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Router Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Output Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Security Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Input Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:09:10 --> Language Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Loader Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:09:10 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:09:10 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Session Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:09:10 --> Session routines successfully run
DEBUG - 2013-09-18 18:09:10 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:09:10 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:10 --> Controller Class Initialized
ERROR - 2013-09-18 18:09:10 --> 404 Page Not Found --> home/asdasd
DEBUG - 2013-09-18 18:09:29 --> Config Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:09:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:09:29 --> URI Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Router Class Initialized
DEBUG - 2013-09-18 18:09:29 --> No URI present. Default controller set.
DEBUG - 2013-09-18 18:09:29 --> Output Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Security Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Input Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:09:29 --> Language Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Loader Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:09:29 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:09:29 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Session Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:09:29 --> A session cookie was not found.
DEBUG - 2013-09-18 18:09:29 --> Session routines successfully run
DEBUG - 2013-09-18 18:09:29 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:09:29 --> Model Class Initialized
DEBUG - 2013-09-18 18:09:29 --> Controller Class Initialized
DEBUG - 2013-09-18 18:09:29 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:09:29 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:09:29 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:09:29 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:09:29 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:09:29 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:09:29 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 18:09:29 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 18:09:29 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:09:29 --> Final output sent to browser
DEBUG - 2013-09-18 18:09:29 --> Total execution time: 0.0280
DEBUG - 2013-09-18 18:16:24 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:24 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:24 --> No URI present. Default controller set.
DEBUG - 2013-09-18 18:16:24 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:24 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:24 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:24 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:24 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:24 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:24 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:24 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:24 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:16:24 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:16:24 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:16:24 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:16:24 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:16:24 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:16:24 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 18:16:24 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 18:16:24 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:16:24 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:24 --> Total execution time: 0.0326
DEBUG - 2013-09-18 18:16:26 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:26 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:26 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:26 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:26 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:26 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:26 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:26 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:26 --> Helper loaded: email_helper
DEBUG - 2013-09-18 18:16:26 --> Helper loaded: form_helper
DEBUG - 2013-09-18 18:16:26 --> Form Validation Class Initialized
DEBUG - 2013-09-18 18:16:26 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:16:26 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:16:26 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:16:26 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:16:26 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
DEBUG - 2013-09-18 18:16:26 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:16:26 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:16:26 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-18 18:16:26 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:16:26 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:26 --> Total execution time: 0.0351
DEBUG - 2013-09-18 18:16:28 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:28 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:28 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:28 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:28 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:28 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:28 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:28 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:28 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:28 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:16:28 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:16:28 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:16:28 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:16:28 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:16:28 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:16:28 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:16:28 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:16:28 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:16:28 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:28 --> Total execution time: 0.0276
DEBUG - 2013-09-18 18:16:32 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:32 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:32 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:32 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:32 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:32 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:32 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:32 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:32 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:32 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:16:32 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:32 --> Total execution time: 0.0728
DEBUG - 2013-09-18 18:16:43 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:43 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:43 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:43 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:43 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:43 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:43 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:43 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:43 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:43 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:16:43 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:16:43 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:16:43 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:16:43 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:16:43 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:16:43 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:16:43 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:16:43 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:16:43 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:43 --> Total execution time: 0.0333
DEBUG - 2013-09-18 18:16:52 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:52 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:52 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:52 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:52 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:52 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:52 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:52 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:52 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:16:52 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:16:52 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:16:52 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:16:52 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:16:52 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:16:52 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:16:52 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:16:52 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:16:52 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:52 --> Total execution time: 0.0297
DEBUG - 2013-09-18 18:16:56 --> Config Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:16:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:16:56 --> URI Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Router Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Output Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Security Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Input Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:16:56 --> Language Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Loader Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:16:56 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:16:56 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Session Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:16:56 --> Session routines successfully run
DEBUG - 2013-09-18 18:16:56 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:16:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:16:56 --> Controller Class Initialized
DEBUG - 2013-09-18 18:16:56 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:16:56 --> Final output sent to browser
DEBUG - 2013-09-18 18:16:56 --> Total execution time: 0.0992
DEBUG - 2013-09-18 18:17:31 --> Config Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:17:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:17:31 --> URI Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Router Class Initialized
DEBUG - 2013-09-18 18:17:31 --> No URI present. Default controller set.
DEBUG - 2013-09-18 18:17:31 --> Output Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Security Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Input Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:17:31 --> Language Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Loader Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:17:31 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:17:31 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Session Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:17:31 --> Session routines successfully run
DEBUG - 2013-09-18 18:17:31 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Model Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Model Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:17:31 --> Model Class Initialized
DEBUG - 2013-09-18 18:17:31 --> Controller Class Initialized
DEBUG - 2013-09-18 18:17:31 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:17:31 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:17:31 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:17:31 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:17:31 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:17:31 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:17:31 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 18:17:31 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 18:17:31 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:17:31 --> Final output sent to browser
DEBUG - 2013-09-18 18:17:31 --> Total execution time: 0.0262
DEBUG - 2013-09-18 18:19:23 --> Config Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:19:23 --> URI Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Router Class Initialized
DEBUG - 2013-09-18 18:19:23 --> No URI present. Default controller set.
DEBUG - 2013-09-18 18:19:23 --> Output Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Security Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Input Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:19:23 --> Language Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Loader Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:19:23 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:19:23 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Session Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:19:23 --> A session cookie was not found.
DEBUG - 2013-09-18 18:19:23 --> Session routines successfully run
DEBUG - 2013-09-18 18:19:23 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Model Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Model Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:19:23 --> Model Class Initialized
DEBUG - 2013-09-18 18:19:23 --> Controller Class Initialized
DEBUG - 2013-09-18 18:19:23 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:19:23 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:19:23 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:19:23 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:19:23 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:19:23 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:19:23 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 18:19:23 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 18:19:23 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:19:23 --> Final output sent to browser
DEBUG - 2013-09-18 18:19:23 --> Total execution time: 0.0259
DEBUG - 2013-09-18 18:26:16 --> Config Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:26:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:26:16 --> URI Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Router Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Output Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Security Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Input Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:26:16 --> Language Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Loader Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:26:16 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:26:16 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Session Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:26:16 --> Session routines successfully run
DEBUG - 2013-09-18 18:26:16 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Model Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Model Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:26:16 --> Model Class Initialized
DEBUG - 2013-09-18 18:26:16 --> Controller Class Initialized
DEBUG - 2013-09-18 18:26:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:26:16 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:26:16 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:26:16 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:26:16 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:26:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:26:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:26:16 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:26:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:26:16 --> Final output sent to browser
DEBUG - 2013-09-18 18:26:16 --> Total execution time: 0.0293
DEBUG - 2013-09-18 18:32:56 --> Config Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:32:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:32:56 --> URI Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Router Class Initialized
DEBUG - 2013-09-18 18:32:56 --> No URI present. Default controller set.
DEBUG - 2013-09-18 18:32:56 --> Output Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Security Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Input Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:32:56 --> Language Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Loader Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:32:56 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:32:56 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Session Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:32:56 --> Session routines successfully run
DEBUG - 2013-09-18 18:32:56 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:32:56 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:56 --> Controller Class Initialized
DEBUG - 2013-09-18 18:32:56 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:32:56 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:32:56 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:32:56 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:32:56 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:32:56 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:32:56 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 18:32:56 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 18:32:56 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:32:56 --> Final output sent to browser
DEBUG - 2013-09-18 18:32:56 --> Total execution time: 0.0285
DEBUG - 2013-09-18 18:32:58 --> Config Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:32:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:32:58 --> URI Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Router Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Output Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Security Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Input Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:32:58 --> Language Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Loader Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:32:58 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:32:58 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Session Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:32:58 --> Session routines successfully run
DEBUG - 2013-09-18 18:32:58 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:32:58 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:58 --> Controller Class Initialized
DEBUG - 2013-09-18 18:32:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:32:58 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:32:58 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:32:58 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:32:58 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:32:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:32:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:32:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:32:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:32:58 --> Final output sent to browser
DEBUG - 2013-09-18 18:32:58 --> Total execution time: 0.0306
DEBUG - 2013-09-18 18:32:59 --> Config Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:32:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:32:59 --> URI Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Router Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Output Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Security Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Input Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:32:59 --> Language Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Loader Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:32:59 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:32:59 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Session Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:32:59 --> Session routines successfully run
DEBUG - 2013-09-18 18:32:59 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:32:59 --> Model Class Initialized
DEBUG - 2013-09-18 18:32:59 --> Controller Class Initialized
DEBUG - 2013-09-18 18:32:59 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:32:59 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:32:59 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:32:59 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:32:59 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:32:59 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:32:59 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:32:59 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:32:59 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:32:59 --> Final output sent to browser
DEBUG - 2013-09-18 18:32:59 --> Total execution time: 0.0256
DEBUG - 2013-09-18 18:33:09 --> Config Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:33:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:33:09 --> URI Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Router Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Output Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Security Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Input Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:33:09 --> Language Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Loader Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:33:09 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:33:09 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Session Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:33:09 --> Session routines successfully run
DEBUG - 2013-09-18 18:33:09 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:33:09 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:09 --> Controller Class Initialized
DEBUG - 2013-09-18 18:33:09 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:33:09 --> Final output sent to browser
DEBUG - 2013-09-18 18:33:09 --> Total execution time: 0.0996
DEBUG - 2013-09-18 18:33:15 --> Config Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:33:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:33:15 --> URI Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Router Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Output Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Security Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Input Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:33:15 --> Language Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Loader Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:33:15 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:33:15 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Session Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:33:15 --> Session routines successfully run
DEBUG - 2013-09-18 18:33:15 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:33:15 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:15 --> Controller Class Initialized
DEBUG - 2013-09-18 18:33:15 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:33:15 --> Final output sent to browser
DEBUG - 2013-09-18 18:33:15 --> Total execution time: 0.1067
DEBUG - 2013-09-18 18:33:47 --> Config Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:33:47 --> URI Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Router Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Output Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Security Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Input Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:33:47 --> Language Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Loader Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:33:47 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:33:47 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Session Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:33:47 --> Session routines successfully run
DEBUG - 2013-09-18 18:33:47 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:33:47 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:47 --> Controller Class Initialized
DEBUG - 2013-09-18 18:33:47 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:33:47 --> Final output sent to browser
DEBUG - 2013-09-18 18:33:47 --> Total execution time: 0.1047
DEBUG - 2013-09-18 18:33:54 --> Config Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:33:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:33:54 --> URI Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Router Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Output Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Security Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Input Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:33:54 --> Language Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Loader Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:33:54 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:33:54 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Session Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:33:54 --> Session routines successfully run
DEBUG - 2013-09-18 18:33:54 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:33:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:33:54 --> Controller Class Initialized
DEBUG - 2013-09-18 18:33:54 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:33:54 --> Final output sent to browser
DEBUG - 2013-09-18 18:33:54 --> Total execution time: 0.0923
DEBUG - 2013-09-18 18:35:42 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:42 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:42 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:42 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:42 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:42 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:42 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:42 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:42 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:42 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:42 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:42 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:42 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:35:42 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:42 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:42 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:42 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:42 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:42 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:42 --> Total execution time: 0.0322
DEBUG - 2013-09-18 18:35:45 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:45 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:45 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:45 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:45 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:45 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:45 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:45 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:45 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:45 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:45 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:45 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:45 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:35:45 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:45 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:45 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:45 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:45 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:45 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:45 --> Total execution time: 0.0327
DEBUG - 2013-09-18 18:35:49 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:49 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:49 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:49 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:49 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:49 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:49 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:49 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:49 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:49 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:49 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:49 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:49 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:35:49 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:49 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:49 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:49 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:49 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:49 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:49 --> Total execution time: 0.0259
DEBUG - 2013-09-18 18:35:50 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:50 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:50 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:50 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:50 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:50 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:50 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:50 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:50 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:50 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:50 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:50 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:35:50 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:35:50 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:50 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:50 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:50 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:50 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:50 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:50 --> Total execution time: 0.0267
DEBUG - 2013-09-18 18:35:51 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:51 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:51 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:51 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:51 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:51 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:51 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:51 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:51 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:51 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:51 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:51 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:35:51 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:51 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:51 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:51 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:51 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:51 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:51 --> Total execution time: 0.0250
DEBUG - 2013-09-18 18:35:52 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:52 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:52 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:52 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:52 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:52 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:52 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:52 --> Helper loaded: email_helper
DEBUG - 2013-09-18 18:35:52 --> Helper loaded: form_helper
DEBUG - 2013-09-18 18:35:52 --> Form Validation Class Initialized
DEBUG - 2013-09-18 18:35:52 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:52 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:52 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:52 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:35:52 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
DEBUG - 2013-09-18 18:35:52 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:52 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:52 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-18 18:35:52 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:52 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:52 --> Total execution time: 0.0290
DEBUG - 2013-09-18 18:35:54 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:54 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:54 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:54 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:54 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:54 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:54 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:54 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:54 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:54 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:54 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:54 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:54 --> Severity: Notice  --> Undefined index: noticias /var/www/ispade/sitio/appweb/views/menu.php 32
ERROR - 2013-09-18 18:35:54 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:54 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:54 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:54 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:54 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:54 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:54 --> Total execution time: 0.0268
DEBUG - 2013-09-18 18:35:55 --> Config Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:35:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:35:55 --> URI Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Router Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Output Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Security Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Input Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:35:55 --> Language Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Loader Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:35:55 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:35:55 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Session Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:35:55 --> Session routines successfully run
DEBUG - 2013-09-18 18:35:55 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:35:55 --> Model Class Initialized
DEBUG - 2013-09-18 18:35:55 --> Controller Class Initialized
DEBUG - 2013-09-18 18:35:55 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:35:55 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:35:55 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:35:55 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:35:55 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:35:55 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:35:55 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:35:55 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:35:55 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:35:55 --> Final output sent to browser
DEBUG - 2013-09-18 18:35:55 --> Total execution time: 0.0267
DEBUG - 2013-09-18 18:38:51 --> Config Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:38:51 --> URI Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Router Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Output Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Security Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Input Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:38:51 --> Language Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Loader Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:38:51 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:38:51 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Session Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:38:51 --> Session routines successfully run
DEBUG - 2013-09-18 18:38:51 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Controller Class Initialized
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:38:51 --> Final output sent to browser
DEBUG - 2013-09-18 18:38:51 --> Total execution time: 0.0347
DEBUG - 2013-09-18 18:38:51 --> Config Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:38:51 --> URI Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Router Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Output Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Security Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Input Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:38:51 --> Language Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Loader Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:38:51 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:38:51 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Session Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:38:51 --> Session routines successfully run
DEBUG - 2013-09-18 18:38:51 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:38:51 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:51 --> Controller Class Initialized
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:38:51 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:38:51 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:38:51 --> Final output sent to browser
DEBUG - 2013-09-18 18:38:51 --> Total execution time: 0.0313
DEBUG - 2013-09-18 18:38:52 --> Config Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:38:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:38:52 --> URI Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Router Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Output Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Security Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Input Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:38:52 --> Language Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Loader Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:38:52 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:38:52 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Session Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:38:52 --> Session routines successfully run
DEBUG - 2013-09-18 18:38:52 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:38:52 --> Model Class Initialized
DEBUG - 2013-09-18 18:38:52 --> Controller Class Initialized
DEBUG - 2013-09-18 18:38:52 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:38:52 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:38:52 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:38:52 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:38:52 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:38:52 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:38:52 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:38:52 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:38:52 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:38:52 --> Final output sent to browser
DEBUG - 2013-09-18 18:38:52 --> Total execution time: 0.0309
DEBUG - 2013-09-18 18:40:21 --> Config Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:40:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:40:21 --> URI Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Router Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Output Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Security Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Input Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:40:21 --> Language Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Loader Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:40:21 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:40:21 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Session Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:40:21 --> Session routines successfully run
DEBUG - 2013-09-18 18:40:21 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:40:21 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:21 --> Controller Class Initialized
DEBUG - 2013-09-18 18:40:21 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:40:21 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:40:21 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:40:21 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:40:21 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:40:21 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:40:21 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:40:21 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:40:21 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:40:21 --> Final output sent to browser
DEBUG - 2013-09-18 18:40:21 --> Total execution time: 0.0278
DEBUG - 2013-09-18 18:40:25 --> Config Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:40:25 --> URI Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Router Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Output Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Security Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Input Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:40:25 --> Language Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Loader Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:40:25 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:40:25 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Session Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:40:25 --> Session routines successfully run
DEBUG - 2013-09-18 18:40:25 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:40:25 --> Model Class Initialized
DEBUG - 2013-09-18 18:40:25 --> Controller Class Initialized
DEBUG - 2013-09-18 18:40:25 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:40:25 --> Final output sent to browser
DEBUG - 2013-09-18 18:40:25 --> Total execution time: 0.2034
DEBUG - 2013-09-18 18:41:41 --> Config Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:41:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:41:41 --> URI Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Router Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Output Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Security Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Input Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:41:41 --> Language Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Loader Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:41:41 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:41:41 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Session Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:41:41 --> Session routines successfully run
DEBUG - 2013-09-18 18:41:41 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:41:41 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:41 --> Controller Class Initialized
DEBUG - 2013-09-18 18:41:41 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 18:41:41 --> Severity: Notice  --> Undefined index: home /var/www/ispade/sitio/appweb/views/menu.php 30
ERROR - 2013-09-18 18:41:41 --> Severity: Notice  --> Undefined index: nosotros /var/www/ispade/sitio/appweb/views/menu.php 31
ERROR - 2013-09-18 18:41:41 --> Severity: Notice  --> Undefined index: servicios /var/www/ispade/sitio/appweb/views/menu.php 33
ERROR - 2013-09-18 18:41:41 --> Severity: Notice  --> Undefined index: contactos /var/www/ispade/sitio/appweb/views/menu.php 34
DEBUG - 2013-09-18 18:41:41 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 18:41:41 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 18:41:41 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 18:41:41 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 18:41:41 --> Final output sent to browser
DEBUG - 2013-09-18 18:41:41 --> Total execution time: 0.0358
DEBUG - 2013-09-18 18:41:44 --> Config Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Hooks Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Utf8 Class Initialized
DEBUG - 2013-09-18 18:41:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 18:41:44 --> URI Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Router Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Output Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Security Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Input Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 18:41:44 --> Language Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Loader Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 18:41:44 --> Helper loaded: url_helper
DEBUG - 2013-09-18 18:41:44 --> Database Driver Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Session Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Helper loaded: string_helper
DEBUG - 2013-09-18 18:41:44 --> Session routines successfully run
DEBUG - 2013-09-18 18:41:44 --> Pagination Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 18:41:44 --> Model Class Initialized
DEBUG - 2013-09-18 18:41:44 --> Controller Class Initialized
DEBUG - 2013-09-18 18:41:44 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 18:41:44 --> Final output sent to browser
DEBUG - 2013-09-18 18:41:44 --> Total execution time: 0.0990
DEBUG - 2013-09-18 22:39:34 --> Config Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:39:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:39:34 --> URI Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Router Class Initialized
DEBUG - 2013-09-18 22:39:34 --> No URI present. Default controller set.
DEBUG - 2013-09-18 22:39:34 --> Output Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Security Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Input Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:39:34 --> Language Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Loader Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:39:34 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:39:34 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Session Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:39:34 --> A session cookie was not found.
DEBUG - 2013-09-18 22:39:34 --> Session routines successfully run
DEBUG - 2013-09-18 22:39:34 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:39:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:34 --> Controller Class Initialized
DEBUG - 2013-09-18 22:39:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:39:34 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:39:34 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:39:34 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 22:39:34 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:39:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:39:34 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 22:39:34 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 22:39:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:39:34 --> Final output sent to browser
DEBUG - 2013-09-18 22:39:34 --> Total execution time: 0.0526
DEBUG - 2013-09-18 22:39:45 --> Config Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:39:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:39:45 --> URI Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Router Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Output Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Security Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Input Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:39:45 --> Language Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Loader Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:39:45 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:39:45 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Session Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:39:45 --> Session routines successfully run
DEBUG - 2013-09-18 22:39:45 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:39:45 --> Model Class Initialized
DEBUG - 2013-09-18 22:39:45 --> Controller Class Initialized
DEBUG - 2013-09-18 22:39:45 --> DB Transaction Failure
ERROR - 2013-09-18 22:39:45 --> Query error: Table 'liposerv_ispade.v_ratings' doesn't exist
DEBUG - 2013-09-18 22:39:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-18 22:43:04 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:04 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:04 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:04 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:04 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:04 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:04 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:04 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:04 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:04 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:43:04 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 22:43:04 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:43:04 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 22:43:04 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:43:04 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:43:04 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 22:43:04 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 22:43:04 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:43:04 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:04 --> Total execution time: 0.0526
DEBUG - 2013-09-18 22:43:07 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:07 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:07 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:07 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:07 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:07 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:07 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:07 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:07 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:07 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 22:43:07 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:07 --> Total execution time: 0.1524
DEBUG - 2013-09-18 22:43:10 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:10 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:10 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:10 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:10 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:10 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:10 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:10 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:10 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:10 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:43:10 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 22:43:10 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:43:10 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:43:10 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:43:10 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:43:10 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 22:43:10 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 22:43:10 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:43:10 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:10 --> Total execution time: 0.0531
DEBUG - 2013-09-18 22:43:13 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:13 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:13 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:13 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:13 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:13 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:13 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:13 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:13 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:13 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 22:43:14 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:14 --> Total execution time: 0.1387
DEBUG - 2013-09-18 22:43:17 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:17 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:17 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:17 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:17 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:17 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:17 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:17 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:17 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:17 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:43:17 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 22:43:17 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:43:17 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:43:17 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:43:17 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:43:17 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 22:43:17 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 22:43:17 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:43:17 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:17 --> Total execution time: 0.0533
DEBUG - 2013-09-18 22:43:19 --> Config Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:43:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:43:19 --> URI Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Router Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Output Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Security Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Input Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:43:19 --> Language Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Loader Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:43:19 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:43:19 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Session Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:43:19 --> Session routines successfully run
DEBUG - 2013-09-18 22:43:19 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:43:19 --> Model Class Initialized
DEBUG - 2013-09-18 22:43:19 --> Controller Class Initialized
DEBUG - 2013-09-18 22:43:19 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 22:43:19 --> Final output sent to browser
DEBUG - 2013-09-18 22:43:19 --> Total execution time: 0.1267
DEBUG - 2013-09-18 22:54:17 --> Config Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:54:17 --> URI Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Router Class Initialized
DEBUG - 2013-09-18 22:54:17 --> No URI present. Default controller set.
DEBUG - 2013-09-18 22:54:17 --> Output Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Security Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Input Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:54:17 --> Language Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Loader Class Initialized
DEBUG - 2013-09-18 22:54:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:54:17 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:54:17 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Session Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:54:18 --> Session routines successfully run
DEBUG - 2013-09-18 22:54:18 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:54:18 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:18 --> Controller Class Initialized
DEBUG - 2013-09-18 22:54:18 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:54:18 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:54:18 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:54:18 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 22:54:18 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:54:18 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:54:18 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 22:54:18 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 22:54:18 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:54:18 --> Final output sent to browser
DEBUG - 2013-09-18 22:54:18 --> Total execution time: 0.0519
DEBUG - 2013-09-18 22:54:20 --> Config Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:54:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:54:20 --> URI Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Router Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Output Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Security Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Input Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:54:20 --> Language Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Loader Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:54:20 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:54:20 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Session Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:54:20 --> Session routines successfully run
DEBUG - 2013-09-18 22:54:20 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:54:20 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:20 --> Controller Class Initialized
DEBUG - 2013-09-18 22:54:20 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:54:20 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 22:54:20 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:54:20 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 22:54:20 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:54:20 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:54:20 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 22:54:20 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 22:54:20 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:54:20 --> Final output sent to browser
DEBUG - 2013-09-18 22:54:20 --> Total execution time: 0.0534
DEBUG - 2013-09-18 22:54:23 --> Config Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:54:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:54:23 --> URI Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Router Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Output Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Security Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Input Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:54:23 --> Language Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Loader Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:54:23 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:54:23 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Session Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:54:23 --> Session routines successfully run
DEBUG - 2013-09-18 22:54:23 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:54:23 --> Model Class Initialized
DEBUG - 2013-09-18 22:54:23 --> Controller Class Initialized
DEBUG - 2013-09-18 22:54:23 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 22:54:23 --> Final output sent to browser
DEBUG - 2013-09-18 22:54:23 --> Total execution time: 0.1229
DEBUG - 2013-09-18 22:59:34 --> Config Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Hooks Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Utf8 Class Initialized
DEBUG - 2013-09-18 22:59:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 22:59:34 --> URI Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Router Class Initialized
DEBUG - 2013-09-18 22:59:34 --> No URI present. Default controller set.
DEBUG - 2013-09-18 22:59:34 --> Output Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Security Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Input Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 22:59:34 --> Language Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Loader Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 22:59:34 --> Helper loaded: url_helper
DEBUG - 2013-09-18 22:59:34 --> Database Driver Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Session Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Helper loaded: string_helper
DEBUG - 2013-09-18 22:59:34 --> A session cookie was not found.
DEBUG - 2013-09-18 22:59:34 --> Session routines successfully run
DEBUG - 2013-09-18 22:59:34 --> Pagination Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 22:59:34 --> Model Class Initialized
DEBUG - 2013-09-18 22:59:34 --> Controller Class Initialized
DEBUG - 2013-09-18 22:59:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 22:59:34 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 22:59:34 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 22:59:34 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 22:59:34 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 22:59:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 22:59:34 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 22:59:34 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 22:59:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 22:59:34 --> Final output sent to browser
DEBUG - 2013-09-18 22:59:34 --> Total execution time: 0.0525
DEBUG - 2013-09-18 23:00:11 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:11 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:11 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:11 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:11 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:11 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:11 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:11 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:11 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:11 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:11 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:11 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:00:11 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:11 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:11 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:11 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:11 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:00:11 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:11 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:11 --> Total execution time: 0.0386
DEBUG - 2013-09-18 23:00:12 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:12 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:12 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:12 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:12 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:12 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:12 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:12 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:12 --> Helper loaded: email_helper
DEBUG - 2013-09-18 23:00:12 --> Helper loaded: form_helper
DEBUG - 2013-09-18 23:00:12 --> Form Validation Class Initialized
DEBUG - 2013-09-18 23:00:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:12 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:12 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:00:12 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-18 23:00:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:12 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:12 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-18 23:00:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:12 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:12 --> Total execution time: 0.0607
DEBUG - 2013-09-18 23:00:16 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:16 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:16 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:16 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:16 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:16 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:16 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:16 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:16 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:16 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:16 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:00:16 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:16 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:16 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:00:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:16 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:16 --> Total execution time: 0.0602
DEBUG - 2013-09-18 23:00:18 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:18 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:18 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:18 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:18 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:18 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:18 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:18 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:18 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:18 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:18 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:18 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:00:18 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:00:18 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:18 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:18 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:18 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:00:18 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:18 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:18 --> Total execution time: 0.0531
DEBUG - 2013-09-18 23:00:19 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:19 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:19 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:19 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:19 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:19 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:19 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:19 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:19 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:19 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:19 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:00:19 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:19 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:19 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:00:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:19 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:19 --> Total execution time: 0.0540
DEBUG - 2013-09-18 23:00:20 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:20 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:20 --> No URI present. Default controller set.
DEBUG - 2013-09-18 23:00:20 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:20 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:20 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:20 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:20 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:20 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:20 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:20 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:20 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:00:20 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:20 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:00:20 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:20 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:20 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 23:00:20 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 23:00:20 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:20 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:20 --> Total execution time: 0.0519
DEBUG - 2013-09-18 23:00:22 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:22 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:22 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:22 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:22 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:22 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:22 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:22 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:22 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:22 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:00:22 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:00:22 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:00:22 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:00:22 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:00:22 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:00:22 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:00:22 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:00:22 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:00:22 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:22 --> Total execution time: 0.0511
DEBUG - 2013-09-18 23:00:24 --> Config Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:00:24 --> URI Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Router Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Output Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Security Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Input Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:00:24 --> Language Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Loader Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:00:24 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:00:24 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Session Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:00:24 --> Session routines successfully run
DEBUG - 2013-09-18 23:00:24 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:00:24 --> Model Class Initialized
DEBUG - 2013-09-18 23:00:24 --> Controller Class Initialized
DEBUG - 2013-09-18 23:00:24 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 23:00:25 --> Final output sent to browser
DEBUG - 2013-09-18 23:00:25 --> Total execution time: 0.2077
DEBUG - 2013-09-18 23:01:32 --> Config Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:01:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:01:32 --> URI Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Router Class Initialized
DEBUG - 2013-09-18 23:01:32 --> No URI present. Default controller set.
DEBUG - 2013-09-18 23:01:32 --> Output Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Security Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Input Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:01:32 --> Language Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Loader Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:01:32 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:01:32 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Session Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:01:32 --> A session cookie was not found.
DEBUG - 2013-09-18 23:01:32 --> Session routines successfully run
DEBUG - 2013-09-18 23:01:32 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:01:32 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:32 --> Controller Class Initialized
DEBUG - 2013-09-18 23:01:32 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:01:32 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:01:32 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:01:32 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:01:32 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:01:32 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:01:32 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 23:01:32 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 23:01:32 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:01:32 --> Final output sent to browser
DEBUG - 2013-09-18 23:01:32 --> Total execution time: 0.0427
DEBUG - 2013-09-18 23:01:33 --> Config Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:01:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:01:33 --> URI Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Router Class Initialized
DEBUG - 2013-09-18 23:01:33 --> No URI present. Default controller set.
DEBUG - 2013-09-18 23:01:33 --> Output Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Security Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Input Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:01:33 --> Language Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Loader Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:01:33 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:01:33 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Session Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:01:33 --> A session cookie was not found.
DEBUG - 2013-09-18 23:01:33 --> Session routines successfully run
DEBUG - 2013-09-18 23:01:33 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:01:33 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:33 --> Controller Class Initialized
DEBUG - 2013-09-18 23:01:33 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:01:33 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:01:33 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:01:33 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:01:33 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:01:33 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:01:33 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 23:01:33 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 23:01:33 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:01:33 --> Final output sent to browser
DEBUG - 2013-09-18 23:01:33 --> Total execution time: 0.0535
DEBUG - 2013-09-18 23:01:54 --> Config Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:01:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:01:54 --> URI Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Router Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Output Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Security Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Input Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:01:54 --> Language Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Loader Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:01:54 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:01:54 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Session Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:01:54 --> Session routines successfully run
DEBUG - 2013-09-18 23:01:54 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:01:54 --> Model Class Initialized
DEBUG - 2013-09-18 23:01:54 --> Controller Class Initialized
DEBUG - 2013-09-18 23:01:54 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:01:54 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:01:54 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:01:54 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:01:54 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:01:54 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:01:54 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:01:54 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-18 23:01:54 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:01:54 --> Final output sent to browser
DEBUG - 2013-09-18 23:01:54 --> Total execution time: 0.0528
DEBUG - 2013-09-18 23:02:20 --> Config Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:02:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:02:20 --> URI Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Router Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Output Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Security Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Input Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:02:20 --> Language Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Loader Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:02:20 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:02:20 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Session Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:02:20 --> Session routines successfully run
DEBUG - 2013-09-18 23:02:20 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:02:20 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:20 --> Controller Class Initialized
DEBUG - 2013-09-18 23:02:20 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-18 23:02:20 --> Final output sent to browser
DEBUG - 2013-09-18 23:02:20 --> Total execution time: 0.1240
DEBUG - 2013-09-18 23:02:38 --> Config Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:02:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:02:38 --> URI Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Router Class Initialized
DEBUG - 2013-09-18 23:02:38 --> No URI present. Default controller set.
DEBUG - 2013-09-18 23:02:38 --> Output Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Security Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Input Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:02:38 --> Language Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Loader Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:02:38 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:02:38 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Session Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:02:38 --> Session routines successfully run
DEBUG - 2013-09-18 23:02:38 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:02:38 --> Model Class Initialized
DEBUG - 2013-09-18 23:02:38 --> Controller Class Initialized
DEBUG - 2013-09-18 23:02:38 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:02:38 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:02:38 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:02:38 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:02:38 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:02:38 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:02:38 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 23:02:38 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 23:02:38 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:02:38 --> Final output sent to browser
DEBUG - 2013-09-18 23:02:38 --> Total execution time: 0.0522
DEBUG - 2013-09-18 23:04:02 --> Config Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:04:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:04:02 --> URI Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Router Class Initialized
DEBUG - 2013-09-18 23:04:02 --> No URI present. Default controller set.
DEBUG - 2013-09-18 23:04:02 --> Output Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Security Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Input Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:04:02 --> Language Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Loader Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:04:02 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:04:02 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Session Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:04:02 --> A session cookie was not found.
DEBUG - 2013-09-18 23:04:02 --> Session routines successfully run
DEBUG - 2013-09-18 23:04:02 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:04:02 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:02 --> Controller Class Initialized
DEBUG - 2013-09-18 23:04:02 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:04:02 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:04:02 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:04:02 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-18 23:04:02 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-18 23:04:02 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:04:02 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-18 23:04:02 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-18 23:04:02 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:04:02 --> Final output sent to browser
DEBUG - 2013-09-18 23:04:02 --> Total execution time: 0.0515
DEBUG - 2013-09-18 23:04:35 --> Config Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Hooks Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Utf8 Class Initialized
DEBUG - 2013-09-18 23:04:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-18 23:04:35 --> URI Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Router Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Output Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Security Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Input Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-18 23:04:35 --> Language Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Loader Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-18 23:04:35 --> Helper loaded: url_helper
DEBUG - 2013-09-18 23:04:35 --> Database Driver Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Session Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Helper loaded: string_helper
DEBUG - 2013-09-18 23:04:35 --> Session routines successfully run
DEBUG - 2013-09-18 23:04:35 --> Pagination Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-18 23:04:35 --> Model Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Controller Class Initialized
DEBUG - 2013-09-18 23:04:35 --> Helper loaded: email_helper
DEBUG - 2013-09-18 23:04:35 --> Helper loaded: form_helper
DEBUG - 2013-09-18 23:04:35 --> Form Validation Class Initialized
DEBUG - 2013-09-18 23:04:35 --> File loaded: appweb/views/header.php
ERROR - 2013-09-18 23:04:35 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-18 23:04:35 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-18 23:04:35 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-18 23:04:35 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-18 23:04:35 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-18 23:04:35 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-18 23:04:35 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-18 23:04:35 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-18 23:04:35 --> Final output sent to browser
DEBUG - 2013-09-18 23:04:35 --> Total execution time: 0.0601
