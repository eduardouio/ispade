<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-28 20:10:09 --> Config Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Hooks Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Utf8 Class Initialized
DEBUG - 2013-09-28 20:10:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-28 20:10:09 --> URI Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Router Class Initialized
DEBUG - 2013-09-28 20:10:09 --> No URI present. Default controller set.
DEBUG - 2013-09-28 20:10:09 --> Output Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Security Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Input Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-28 20:10:09 --> Language Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Loader Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-28 20:10:09 --> Helper loaded: url_helper
DEBUG - 2013-09-28 20:10:09 --> Database Driver Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Session Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Helper loaded: string_helper
DEBUG - 2013-09-28 20:10:09 --> A session cookie was not found.
DEBUG - 2013-09-28 20:10:09 --> Session routines successfully run
DEBUG - 2013-09-28 20:10:09 --> Pagination Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Model Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Model Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-28 20:10:09 --> Model Class Initialized
DEBUG - 2013-09-28 20:10:09 --> Controller Class Initialized
DEBUG - 2013-09-28 20:10:09 --> File loaded: appweb/views/header.php
ERROR - 2013-09-28 20:10:09 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-28 20:10:09 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-28 20:10:09 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-28 20:10:09 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-28 20:10:09 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-28 20:10:09 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-28 20:10:09 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-28 20:10:09 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-28 20:10:09 --> Final output sent to browser
DEBUG - 2013-09-28 20:10:09 --> Total execution time: 0.1650
