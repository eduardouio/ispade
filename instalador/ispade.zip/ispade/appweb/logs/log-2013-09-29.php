<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-29 11:02:56 --> Config Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Hooks Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Utf8 Class Initialized
DEBUG - 2013-09-29 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 11:02:56 --> URI Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Router Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Output Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Security Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Input Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 11:02:56 --> Language Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Loader Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 11:02:56 --> Helper loaded: url_helper
DEBUG - 2013-09-29 11:02:56 --> Database Driver Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Session Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Helper loaded: string_helper
DEBUG - 2013-09-29 11:02:56 --> A session cookie was not found.
DEBUG - 2013-09-29 11:02:56 --> Session routines successfully run
DEBUG - 2013-09-29 11:02:56 --> Pagination Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Model Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Model Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 11:02:56 --> Model Class Initialized
DEBUG - 2013-09-29 11:02:56 --> Controller Class Initialized
DEBUG - 2013-09-29 11:02:56 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 11:02:56 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 11:02:56 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 11:02:56 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 11:02:56 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 11:02:56 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 11:02:56 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 11:02:56 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-29 11:02:56 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 11:02:56 --> Final output sent to browser
DEBUG - 2013-09-29 11:02:56 --> Total execution time: 0.0706
DEBUG - 2013-09-29 11:04:07 --> Config Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Hooks Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Utf8 Class Initialized
DEBUG - 2013-09-29 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 11:04:07 --> URI Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Router Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Output Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Security Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Input Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 11:04:07 --> Language Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Loader Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 11:04:07 --> Helper loaded: url_helper
DEBUG - 2013-09-29 11:04:07 --> Database Driver Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Session Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Helper loaded: string_helper
DEBUG - 2013-09-29 11:04:07 --> Session routines successfully run
DEBUG - 2013-09-29 11:04:07 --> Pagination Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 11:04:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Controller Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Helper loaded: email_helper
DEBUG - 2013-09-29 11:04:07 --> Helper loaded: form_helper
DEBUG - 2013-09-29 11:04:07 --> Form Validation Class Initialized
DEBUG - 2013-09-29 11:04:07 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 11:04:07 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 11:04:07 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 11:04:07 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 11:04:07 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-29 11:04:07 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 11:04:07 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 11:04:07 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-29 11:04:07 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 11:04:07 --> Final output sent to browser
DEBUG - 2013-09-29 11:04:07 --> Total execution time: 0.1131
DEBUG - 2013-09-29 11:04:07 --> Config Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Hooks Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Utf8 Class Initialized
DEBUG - 2013-09-29 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 11:04:07 --> URI Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Router Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Output Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Security Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Input Class Initialized
DEBUG - 2013-09-29 11:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 11:04:07 --> Language Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Loader Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 11:04:08 --> Helper loaded: url_helper
DEBUG - 2013-09-29 11:04:08 --> Database Driver Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Session Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Helper loaded: string_helper
DEBUG - 2013-09-29 11:04:08 --> Session routines successfully run
DEBUG - 2013-09-29 11:04:08 --> Pagination Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 11:04:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Controller Class Initialized
DEBUG - 2013-09-29 11:04:08 --> Helper loaded: email_helper
DEBUG - 2013-09-29 11:04:08 --> Helper loaded: form_helper
DEBUG - 2013-09-29 11:04:08 --> Form Validation Class Initialized
DEBUG - 2013-09-29 11:04:08 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 11:04:08 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 11:04:08 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 11:04:08 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 11:04:08 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-29 11:04:08 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 11:04:08 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 11:04:08 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-29 11:04:08 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 11:04:08 --> Final output sent to browser
DEBUG - 2013-09-29 11:04:08 --> Total execution time: 0.0416
DEBUG - 2013-09-29 11:09:07 --> Config Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Hooks Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Utf8 Class Initialized
DEBUG - 2013-09-29 11:09:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 11:09:07 --> URI Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Router Class Initialized
DEBUG - 2013-09-29 11:09:07 --> No URI present. Default controller set.
DEBUG - 2013-09-29 11:09:07 --> Output Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Security Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Input Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 11:09:07 --> Language Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Loader Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 11:09:07 --> Helper loaded: url_helper
DEBUG - 2013-09-29 11:09:07 --> Database Driver Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Session Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Helper loaded: string_helper
DEBUG - 2013-09-29 11:09:07 --> Session routines successfully run
DEBUG - 2013-09-29 11:09:07 --> Pagination Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 11:09:07 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:07 --> Controller Class Initialized
DEBUG - 2013-09-29 11:09:07 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 11:09:07 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 11:09:07 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 11:09:07 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 11:09:07 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 11:09:07 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 11:09:07 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-29 11:09:07 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-29 11:09:07 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 11:09:07 --> Final output sent to browser
DEBUG - 2013-09-29 11:09:07 --> Total execution time: 0.0849
DEBUG - 2013-09-29 11:09:08 --> Config Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Hooks Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Utf8 Class Initialized
DEBUG - 2013-09-29 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 11:09:08 --> URI Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Router Class Initialized
DEBUG - 2013-09-29 11:09:08 --> No URI present. Default controller set.
DEBUG - 2013-09-29 11:09:08 --> Output Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Security Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Input Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 11:09:08 --> Language Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Loader Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 11:09:08 --> Helper loaded: url_helper
DEBUG - 2013-09-29 11:09:08 --> Database Driver Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Session Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Helper loaded: string_helper
DEBUG - 2013-09-29 11:09:08 --> Session routines successfully run
DEBUG - 2013-09-29 11:09:08 --> Pagination Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 11:09:08 --> Model Class Initialized
DEBUG - 2013-09-29 11:09:08 --> Controller Class Initialized
DEBUG - 2013-09-29 11:09:08 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 11:09:08 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 11:09:08 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 11:09:08 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 11:09:08 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 11:09:08 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 11:09:08 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-29 11:09:08 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-29 11:09:08 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 11:09:08 --> Final output sent to browser
DEBUG - 2013-09-29 11:09:08 --> Total execution time: 0.0285
DEBUG - 2013-09-29 17:42:54 --> Config Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Hooks Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Utf8 Class Initialized
DEBUG - 2013-09-29 17:42:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 17:42:54 --> URI Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Router Class Initialized
DEBUG - 2013-09-29 17:42:54 --> No URI present. Default controller set.
DEBUG - 2013-09-29 17:42:54 --> Output Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Security Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Input Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 17:42:54 --> Language Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Loader Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 17:42:54 --> Helper loaded: url_helper
DEBUG - 2013-09-29 17:42:54 --> Database Driver Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Session Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Helper loaded: string_helper
DEBUG - 2013-09-29 17:42:54 --> Session routines successfully run
DEBUG - 2013-09-29 17:42:54 --> Pagination Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Model Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Model Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 17:42:54 --> Model Class Initialized
DEBUG - 2013-09-29 17:42:54 --> Controller Class Initialized
DEBUG - 2013-09-29 17:42:54 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 17:42:54 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 17:42:54 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 17:42:54 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 17:42:54 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 17:42:54 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 17:42:54 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-29 17:42:54 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-29 17:42:54 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 17:42:54 --> Final output sent to browser
DEBUG - 2013-09-29 17:42:54 --> Total execution time: 0.0389
DEBUG - 2013-09-29 19:18:21 --> Config Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Hooks Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Utf8 Class Initialized
DEBUG - 2013-09-29 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 19:18:21 --> URI Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Router Class Initialized
DEBUG - 2013-09-29 19:18:21 --> No URI present. Default controller set.
DEBUG - 2013-09-29 19:18:21 --> Output Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Security Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Input Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 19:18:21 --> Language Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Loader Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 19:18:21 --> Helper loaded: url_helper
DEBUG - 2013-09-29 19:18:21 --> Database Driver Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Session Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Helper loaded: string_helper
DEBUG - 2013-09-29 19:18:21 --> Session routines successfully run
DEBUG - 2013-09-29 19:18:21 --> Pagination Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Model Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Model Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 19:18:21 --> Model Class Initialized
DEBUG - 2013-09-29 19:18:21 --> Controller Class Initialized
DEBUG - 2013-09-29 19:18:21 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 19:18:21 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 19:18:21 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 19:18:21 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 19:18:21 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 19:18:21 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 19:18:21 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-29 19:18:21 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-29 19:18:21 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 19:18:21 --> Final output sent to browser
DEBUG - 2013-09-29 19:18:21 --> Total execution time: 0.0419
DEBUG - 2013-09-29 19:20:39 --> Config Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Hooks Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Utf8 Class Initialized
DEBUG - 2013-09-29 19:20:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 19:20:39 --> URI Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Router Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Output Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Security Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Input Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 19:20:39 --> Language Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Loader Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 19:20:39 --> Helper loaded: url_helper
DEBUG - 2013-09-29 19:20:39 --> Database Driver Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Session Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Helper loaded: string_helper
DEBUG - 2013-09-29 19:20:39 --> Session routines successfully run
DEBUG - 2013-09-29 19:20:39 --> Pagination Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Controller Class Initialized
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 19:20:39 --> Final output sent to browser
DEBUG - 2013-09-29 19:20:39 --> Total execution time: 0.0576
DEBUG - 2013-09-29 19:20:39 --> Config Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Hooks Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Utf8 Class Initialized
DEBUG - 2013-09-29 19:20:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 19:20:39 --> URI Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Router Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Output Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Security Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Input Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 19:20:39 --> Language Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Loader Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 19:20:39 --> Helper loaded: url_helper
DEBUG - 2013-09-29 19:20:39 --> Database Driver Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Session Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Helper loaded: string_helper
DEBUG - 2013-09-29 19:20:39 --> Session routines successfully run
DEBUG - 2013-09-29 19:20:39 --> Pagination Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 19:20:39 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:39 --> Controller Class Initialized
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 19:20:39 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-29 19:20:39 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 19:20:39 --> Final output sent to browser
DEBUG - 2013-09-29 19:20:39 --> Total execution time: 0.0523
DEBUG - 2013-09-29 19:20:41 --> Config Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Hooks Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Utf8 Class Initialized
DEBUG - 2013-09-29 19:20:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 19:20:41 --> URI Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Router Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Output Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Security Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Input Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 19:20:41 --> Language Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Loader Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 19:20:41 --> Helper loaded: url_helper
DEBUG - 2013-09-29 19:20:41 --> Database Driver Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Session Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Helper loaded: string_helper
DEBUG - 2013-09-29 19:20:41 --> Session routines successfully run
DEBUG - 2013-09-29 19:20:41 --> Pagination Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 19:20:41 --> Model Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Controller Class Initialized
DEBUG - 2013-09-29 19:20:41 --> Helper loaded: email_helper
DEBUG - 2013-09-29 19:20:41 --> Helper loaded: form_helper
DEBUG - 2013-09-29 19:20:41 --> Form Validation Class Initialized
DEBUG - 2013-09-29 19:20:41 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 19:20:41 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-29 19:20:41 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 19:20:41 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 19:20:41 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-29 19:20:41 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 19:20:41 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-29 19:20:41 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-29 19:20:41 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 19:20:41 --> Final output sent to browser
DEBUG - 2013-09-29 19:20:41 --> Total execution time: 0.0559
DEBUG - 2013-09-29 19:53:14 --> Config Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Hooks Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Utf8 Class Initialized
DEBUG - 2013-09-29 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-29 19:53:14 --> URI Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Router Class Initialized
DEBUG - 2013-09-29 19:53:14 --> No URI present. Default controller set.
DEBUG - 2013-09-29 19:53:14 --> Output Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Security Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Input Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-29 19:53:14 --> Language Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Loader Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-29 19:53:14 --> Helper loaded: url_helper
DEBUG - 2013-09-29 19:53:14 --> Database Driver Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Session Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Helper loaded: string_helper
DEBUG - 2013-09-29 19:53:14 --> Session routines successfully run
DEBUG - 2013-09-29 19:53:14 --> Pagination Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Model Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Model Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-29 19:53:14 --> Model Class Initialized
DEBUG - 2013-09-29 19:53:14 --> Controller Class Initialized
DEBUG - 2013-09-29 19:53:14 --> File loaded: appweb/views/header.php
ERROR - 2013-09-29 19:53:14 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-29 19:53:14 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-29 19:53:14 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-29 19:53:14 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-29 19:53:14 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-29 19:53:14 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-29 19:53:14 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-29 19:53:14 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-29 19:53:14 --> Final output sent to browser
DEBUG - 2013-09-29 19:53:14 --> Total execution time: 0.0458
