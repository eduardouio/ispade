<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-30 17:43:09 --> Config Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:43:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:43:09 --> URI Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Router Class Initialized
DEBUG - 2013-09-30 17:43:09 --> No URI present. Default controller set.
DEBUG - 2013-09-30 17:43:09 --> Output Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Security Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Input Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:43:09 --> Language Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Loader Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:43:09 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:43:09 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Session Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:43:09 --> A session cookie was not found.
DEBUG - 2013-09-30 17:43:09 --> Session routines successfully run
DEBUG - 2013-09-30 17:43:09 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:43:09 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:09 --> Controller Class Initialized
DEBUG - 2013-09-30 17:43:09 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:43:09 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:43:09 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:43:09 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-30 17:43:09 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:43:09 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:43:09 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-30 17:43:09 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-30 17:43:09 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:43:09 --> Final output sent to browser
DEBUG - 2013-09-30 17:43:09 --> Total execution time: 0.1378
DEBUG - 2013-09-30 17:43:23 --> Config Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:43:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:43:23 --> URI Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Router Class Initialized
DEBUG - 2013-09-30 17:43:23 --> No URI present. Default controller set.
DEBUG - 2013-09-30 17:43:23 --> Output Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Security Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Input Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:43:23 --> Language Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Loader Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:43:23 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:43:23 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Session Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:43:23 --> Session routines successfully run
DEBUG - 2013-09-30 17:43:23 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:43:23 --> Model Class Initialized
DEBUG - 2013-09-30 17:43:23 --> Controller Class Initialized
DEBUG - 2013-09-30 17:43:23 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:43:23 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:43:23 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:43:23 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-30 17:43:23 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:43:23 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:43:23 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-30 17:43:23 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-30 17:43:23 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:43:23 --> Final output sent to browser
DEBUG - 2013-09-30 17:43:23 --> Total execution time: 0.0478
DEBUG - 2013-09-30 17:44:41 --> Config Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:44:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:44:41 --> URI Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Router Class Initialized
DEBUG - 2013-09-30 17:44:41 --> No URI present. Default controller set.
DEBUG - 2013-09-30 17:44:41 --> Output Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Security Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Input Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:44:41 --> Language Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Loader Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:44:41 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:44:41 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Session Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:44:41 --> A session cookie was not found.
DEBUG - 2013-09-30 17:44:41 --> Session routines successfully run
DEBUG - 2013-09-30 17:44:41 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:44:41 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:41 --> Controller Class Initialized
DEBUG - 2013-09-30 17:44:41 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:44:41 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:44:41 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:44:41 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-30 17:44:41 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:44:41 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:44:41 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-30 17:44:41 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-30 17:44:41 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:44:41 --> Final output sent to browser
DEBUG - 2013-09-30 17:44:41 --> Total execution time: 0.0512
DEBUG - 2013-09-30 17:44:57 --> Config Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:44:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:44:57 --> URI Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Router Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Output Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Security Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Input Class Initialized
DEBUG - 2013-09-30 17:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:44:57 --> Language Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Loader Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:44:58 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:44:58 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Session Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:44:58 --> A session cookie was not found.
DEBUG - 2013-09-30 17:44:58 --> Session routines successfully run
DEBUG - 2013-09-30 17:44:58 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Controller Class Initialized
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-30 17:44:58 --> Config Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:44:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:44:58 --> URI Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Router Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Output Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Security Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Input Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:44:58 --> Language Class Initialized
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:44:58 --> Final output sent to browser
DEBUG - 2013-09-30 17:44:58 --> Total execution time: 0.9723
DEBUG - 2013-09-30 17:44:58 --> Loader Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:44:58 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:44:58 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Session Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:44:58 --> A session cookie was not found.
DEBUG - 2013-09-30 17:44:58 --> Session routines successfully run
DEBUG - 2013-09-30 17:44:58 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:44:58 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:58 --> Controller Class Initialized
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-30 17:44:58 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-30 17:44:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:44:58 --> Final output sent to browser
DEBUG - 2013-09-30 17:44:58 --> Total execution time: 0.1162
DEBUG - 2013-09-30 17:44:59 --> Config Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:44:59 --> URI Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Router Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Output Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Security Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Input Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:44:59 --> Language Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Loader Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:44:59 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Session Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:44:59 --> Session routines successfully run
DEBUG - 2013-09-30 17:44:59 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Controller Class Initialized
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:44:59 --> Final output sent to browser
DEBUG - 2013-09-30 17:44:59 --> Total execution time: 0.0649
DEBUG - 2013-09-30 17:44:59 --> Config Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Hooks Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Utf8 Class Initialized
DEBUG - 2013-09-30 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-30 17:44:59 --> URI Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Router Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Output Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Security Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Input Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-30 17:44:59 --> Language Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Loader Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: url_helper
DEBUG - 2013-09-30 17:44:59 --> Database Driver Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Session Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: string_helper
DEBUG - 2013-09-30 17:44:59 --> Session routines successfully run
DEBUG - 2013-09-30 17:44:59 --> Pagination Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-30 17:44:59 --> Model Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Controller Class Initialized
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: email_helper
DEBUG - 2013-09-30 17:44:59 --> Helper loaded: form_helper
DEBUG - 2013-09-30 17:44:59 --> Form Validation Class Initialized
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/header.php
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-30 17:44:59 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-30 17:44:59 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-30 17:44:59 --> Final output sent to browser
DEBUG - 2013-09-30 17:44:59 --> Total execution time: 0.6016
