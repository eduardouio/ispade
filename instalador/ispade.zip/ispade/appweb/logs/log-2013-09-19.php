<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-19 00:07:54 --> Config Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Hooks Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Utf8 Class Initialized
DEBUG - 2013-09-19 00:07:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 00:07:54 --> URI Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Router Class Initialized
DEBUG - 2013-09-19 00:07:54 --> No URI present. Default controller set.
DEBUG - 2013-09-19 00:07:54 --> Output Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Security Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Input Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 00:07:54 --> Language Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Loader Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 00:07:54 --> Helper loaded: url_helper
DEBUG - 2013-09-19 00:07:54 --> Database Driver Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Session Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Helper loaded: string_helper
DEBUG - 2013-09-19 00:07:54 --> A session cookie was not found.
DEBUG - 2013-09-19 00:07:54 --> Session routines successfully run
DEBUG - 2013-09-19 00:07:54 --> Pagination Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 00:07:54 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:54 --> Controller Class Initialized
DEBUG - 2013-09-19 00:07:54 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 00:07:54 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 00:07:54 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 00:07:54 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 00:07:54 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 00:07:54 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 00:07:54 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 00:07:54 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 00:07:54 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 00:07:54 --> Final output sent to browser
DEBUG - 2013-09-19 00:07:54 --> Total execution time: 0.0293
DEBUG - 2013-09-19 00:07:55 --> Config Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Hooks Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Utf8 Class Initialized
DEBUG - 2013-09-19 00:07:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 00:07:55 --> URI Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Router Class Initialized
DEBUG - 2013-09-19 00:07:55 --> No URI present. Default controller set.
DEBUG - 2013-09-19 00:07:55 --> Output Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Security Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Input Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 00:07:55 --> Language Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Loader Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 00:07:55 --> Helper loaded: url_helper
DEBUG - 2013-09-19 00:07:55 --> Database Driver Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Session Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Helper loaded: string_helper
DEBUG - 2013-09-19 00:07:55 --> A session cookie was not found.
DEBUG - 2013-09-19 00:07:55 --> Session routines successfully run
DEBUG - 2013-09-19 00:07:55 --> Pagination Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 00:07:55 --> Model Class Initialized
DEBUG - 2013-09-19 00:07:55 --> Controller Class Initialized
DEBUG - 2013-09-19 00:07:55 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 00:07:55 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 00:07:55 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 00:07:55 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 00:07:55 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 00:07:55 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 00:07:55 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 00:07:55 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 00:07:55 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 00:07:55 --> Final output sent to browser
DEBUG - 2013-09-19 00:07:55 --> Total execution time: 0.0529
DEBUG - 2013-09-19 07:29:40 --> Config Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:29:40 --> URI Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Router Class Initialized
DEBUG - 2013-09-19 07:29:40 --> No URI present. Default controller set.
DEBUG - 2013-09-19 07:29:40 --> Output Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Security Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Input Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:29:40 --> Language Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Loader Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:29:40 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:29:40 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Session Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:29:40 --> A session cookie was not found.
DEBUG - 2013-09-19 07:29:40 --> Session routines successfully run
DEBUG - 2013-09-19 07:29:40 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:29:40 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:40 --> Controller Class Initialized
DEBUG - 2013-09-19 07:29:40 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:29:40 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 07:29:40 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 07:29:40 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 07:29:40 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:29:40 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:29:40 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 07:29:40 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 07:29:40 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:29:40 --> Final output sent to browser
DEBUG - 2013-09-19 07:29:40 --> Total execution time: 0.1289
DEBUG - 2013-09-19 07:29:48 --> Config Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:29:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:29:48 --> URI Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Router Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Output Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Security Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Input Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:29:48 --> Language Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Loader Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:29:48 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:29:48 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Session Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:29:48 --> Session routines successfully run
DEBUG - 2013-09-19 07:29:48 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:29:48 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:48 --> Controller Class Initialized
DEBUG - 2013-09-19 07:29:48 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:29:48 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:29:48 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 07:29:48 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 07:29:48 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:29:48 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:29:48 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:29:48 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 07:29:48 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:29:48 --> Final output sent to browser
DEBUG - 2013-09-19 07:29:48 --> Total execution time: 0.1111
DEBUG - 2013-09-19 07:29:56 --> Config Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:29:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:29:56 --> URI Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Router Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Output Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Security Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Input Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:29:56 --> Language Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Loader Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:29:56 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:29:56 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Session Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:29:56 --> Session routines successfully run
DEBUG - 2013-09-19 07:29:56 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:29:56 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:56 --> Controller Class Initialized
DEBUG - 2013-09-19 07:29:56 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:29:56 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:29:56 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 07:29:56 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 07:29:56 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:29:56 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:29:56 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:29:56 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 07:29:56 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:29:56 --> Final output sent to browser
DEBUG - 2013-09-19 07:29:56 --> Total execution time: 0.0735
DEBUG - 2013-09-19 07:29:58 --> Config Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:29:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:29:58 --> URI Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Router Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Output Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Security Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Input Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:29:58 --> Language Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Loader Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:29:58 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:29:58 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Session Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:29:58 --> Session routines successfully run
DEBUG - 2013-09-19 07:29:58 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:29:58 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:58 --> Controller Class Initialized
DEBUG - 2013-09-19 07:29:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:29:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:29:58 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 07:29:58 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 07:29:58 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:29:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:29:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:29:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 07:29:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:29:58 --> Final output sent to browser
DEBUG - 2013-09-19 07:29:58 --> Total execution time: 0.0898
DEBUG - 2013-09-19 07:29:59 --> Config Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:29:59 --> URI Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Router Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Output Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Security Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Input Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:29:59 --> Language Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Loader Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:29:59 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:29:59 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Session Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:29:59 --> Session routines successfully run
DEBUG - 2013-09-19 07:29:59 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:29:59 --> Model Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Controller Class Initialized
DEBUG - 2013-09-19 07:29:59 --> Helper loaded: email_helper
DEBUG - 2013-09-19 07:29:59 --> Helper loaded: form_helper
DEBUG - 2013-09-19 07:29:59 --> Form Validation Class Initialized
DEBUG - 2013-09-19 07:29:59 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:29:59 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:29:59 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 07:29:59 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 07:29:59 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 07:29:59 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:29:59 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:29:59 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 07:29:59 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:29:59 --> Final output sent to browser
DEBUG - 2013-09-19 07:29:59 --> Total execution time: 0.0843
DEBUG - 2013-09-19 07:30:08 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:08 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:08 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:08 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:08 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:08 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:08 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:08 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:08 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:08 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:30:08 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:30:08 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 07:30:08 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 07:30:08 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:30:08 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:30:08 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:30:08 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 07:30:08 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:30:08 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:08 --> Total execution time: 0.0603
DEBUG - 2013-09-19 07:30:14 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:14 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:14 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:14 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:14 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:14 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:14 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:14 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:14 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:14 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 07:30:15 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:15 --> Total execution time: 0.2516
DEBUG - 2013-09-19 07:30:15 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:15 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:15 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:15 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:15 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:15 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:15 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:15 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:15 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:15 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 07:30:15 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:15 --> Total execution time: 0.1256
DEBUG - 2013-09-19 07:30:20 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:20 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:20 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:20 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:20 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:20 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:20 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:20 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:20 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:20 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 07:30:20 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 07:30:20 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 07:30:20 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 07:30:20 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 07:30:20 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 07:30:20 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 07:30:20 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 07:30:20 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 07:30:20 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:20 --> Total execution time: 0.0529
DEBUG - 2013-09-19 07:30:23 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:23 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:23 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:23 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:23 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:23 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:23 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:23 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:23 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:23 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 07:30:24 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:24 --> Total execution time: 1.1176
DEBUG - 2013-09-19 07:30:25 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:25 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:25 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:25 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:25 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:25 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:25 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:25 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:25 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:25 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 07:30:25 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:25 --> Total execution time: 0.0593
DEBUG - 2013-09-19 07:30:28 --> Config Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Hooks Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Utf8 Class Initialized
DEBUG - 2013-09-19 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 07:30:28 --> URI Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Router Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Output Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Security Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Input Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 07:30:28 --> Language Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Loader Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 07:30:28 --> Helper loaded: url_helper
DEBUG - 2013-09-19 07:30:28 --> Database Driver Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Session Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Helper loaded: string_helper
DEBUG - 2013-09-19 07:30:28 --> Session routines successfully run
DEBUG - 2013-09-19 07:30:28 --> Pagination Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 07:30:28 --> Model Class Initialized
DEBUG - 2013-09-19 07:30:28 --> Controller Class Initialized
DEBUG - 2013-09-19 07:30:28 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 07:30:28 --> Final output sent to browser
DEBUG - 2013-09-19 07:30:28 --> Total execution time: 0.2679
DEBUG - 2013-09-19 09:05:36 --> Config Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Hooks Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Utf8 Class Initialized
DEBUG - 2013-09-19 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 09:05:36 --> URI Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Router Class Initialized
DEBUG - 2013-09-19 09:05:36 --> No URI present. Default controller set.
DEBUG - 2013-09-19 09:05:36 --> Output Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Security Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Input Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 09:05:36 --> Language Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Loader Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 09:05:36 --> Helper loaded: url_helper
DEBUG - 2013-09-19 09:05:36 --> Database Driver Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Session Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Helper loaded: string_helper
DEBUG - 2013-09-19 09:05:36 --> A session cookie was not found.
DEBUG - 2013-09-19 09:05:36 --> Session routines successfully run
DEBUG - 2013-09-19 09:05:36 --> Pagination Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 09:05:36 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:36 --> Controller Class Initialized
DEBUG - 2013-09-19 09:05:36 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 09:05:36 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 09:05:36 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 09:05:36 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 09:05:36 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 09:05:36 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 09:05:36 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 09:05:36 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 09:05:36 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 09:05:36 --> Final output sent to browser
DEBUG - 2013-09-19 09:05:36 --> Total execution time: 0.0544
DEBUG - 2013-09-19 09:05:43 --> Config Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Hooks Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Utf8 Class Initialized
DEBUG - 2013-09-19 09:05:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 09:05:43 --> URI Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Router Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Output Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Security Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Input Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 09:05:43 --> Language Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Loader Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 09:05:43 --> Helper loaded: url_helper
DEBUG - 2013-09-19 09:05:43 --> Database Driver Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Session Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Helper loaded: string_helper
DEBUG - 2013-09-19 09:05:43 --> Session routines successfully run
DEBUG - 2013-09-19 09:05:43 --> Pagination Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 09:05:43 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:43 --> Controller Class Initialized
DEBUG - 2013-09-19 09:05:43 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 09:05:43 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 09:05:43 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 09:05:43 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 09:05:43 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 09:05:43 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 09:05:43 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 09:05:43 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 09:05:43 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 09:05:43 --> Final output sent to browser
DEBUG - 2013-09-19 09:05:43 --> Total execution time: 0.0530
DEBUG - 2013-09-19 09:05:45 --> Config Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Hooks Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Utf8 Class Initialized
DEBUG - 2013-09-19 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 09:05:45 --> URI Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Router Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Output Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Security Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Input Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 09:05:45 --> Language Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Loader Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 09:05:45 --> Helper loaded: url_helper
DEBUG - 2013-09-19 09:05:45 --> Database Driver Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Session Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Helper loaded: string_helper
DEBUG - 2013-09-19 09:05:45 --> Session routines successfully run
DEBUG - 2013-09-19 09:05:45 --> Pagination Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 09:05:45 --> Model Class Initialized
DEBUG - 2013-09-19 09:05:45 --> Controller Class Initialized
DEBUG - 2013-09-19 09:05:45 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 09:05:45 --> Final output sent to browser
DEBUG - 2013-09-19 09:05:45 --> Total execution time: 0.3726
DEBUG - 2013-09-19 11:57:22 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:22 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:22 --> No URI present. Default controller set.
DEBUG - 2013-09-19 11:57:22 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:22 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:22 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:22 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:22 --> A session cookie was not found.
DEBUG - 2013-09-19 11:57:22 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:22 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:22 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:22 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:22 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 11:57:22 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 11:57:22 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 11:57:22 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 11:57:22 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 11:57:22 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 11:57:22 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 11:57:22 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 11:57:22 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 11:57:22 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:22 --> Total execution time: 0.0540
DEBUG - 2013-09-19 11:57:29 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:29 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:29 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:29 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:29 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:29 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:29 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:29 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:29 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:29 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 11:57:29 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 11:57:29 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 11:57:29 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 11:57:29 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 11:57:29 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 11:57:29 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 11:57:29 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 11:57:29 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 11:57:29 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:29 --> Total execution time: 0.0537
DEBUG - 2013-09-19 11:57:32 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:32 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:32 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:32 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:32 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:32 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:32 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:32 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:32 --> Helper loaded: email_helper
DEBUG - 2013-09-19 11:57:32 --> Helper loaded: form_helper
DEBUG - 2013-09-19 11:57:32 --> Form Validation Class Initialized
DEBUG - 2013-09-19 11:57:32 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 11:57:32 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 11:57:32 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 11:57:32 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 11:57:32 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 11:57:32 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 11:57:32 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 11:57:32 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 11:57:32 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 11:57:32 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:32 --> Total execution time: 0.0957
DEBUG - 2013-09-19 11:57:36 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:36 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:36 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:36 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:36 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:36 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:36 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:36 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:36 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:36 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 11:57:36 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 11:57:36 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 11:57:36 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 11:57:36 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 11:57:36 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 11:57:36 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 11:57:36 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 11:57:36 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 11:57:36 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:36 --> Total execution time: 0.0739
DEBUG - 2013-09-19 11:57:39 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:39 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:39 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:39 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:39 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:39 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:39 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:39 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:39 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:39 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 11:57:39 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 11:57:39 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 11:57:39 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 11:57:39 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 11:57:39 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 11:57:39 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 11:57:39 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 11:57:39 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 11:57:39 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:39 --> Total execution time: 0.0379
DEBUG - 2013-09-19 11:57:41 --> Config Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Hooks Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Utf8 Class Initialized
DEBUG - 2013-09-19 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 11:57:41 --> URI Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Router Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Output Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Security Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Input Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 11:57:41 --> Language Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Loader Class Initialized
DEBUG - 2013-09-19 11:57:41 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 11:57:41 --> Helper loaded: url_helper
DEBUG - 2013-09-19 11:57:42 --> Database Driver Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Session Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Helper loaded: string_helper
DEBUG - 2013-09-19 11:57:42 --> Session routines successfully run
DEBUG - 2013-09-19 11:57:42 --> Pagination Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 11:57:42 --> Model Class Initialized
DEBUG - 2013-09-19 11:57:42 --> Controller Class Initialized
DEBUG - 2013-09-19 11:57:42 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 11:57:42 --> Final output sent to browser
DEBUG - 2013-09-19 11:57:42 --> Total execution time: 0.2750
DEBUG - 2013-09-19 15:25:00 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:00 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:00 --> No URI present. Default controller set.
DEBUG - 2013-09-19 15:25:00 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:00 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:00 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:00 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:00 --> A session cookie was not found.
DEBUG - 2013-09-19 15:25:00 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:00 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:00 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:00 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:00 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:00 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:00 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:00 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:00 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:00 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:00 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 15:25:00 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 15:25:00 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:00 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:00 --> Total execution time: 0.0532
DEBUG - 2013-09-19 15:25:03 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:03 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:03 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:03 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:03 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:03 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:03 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:03 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:03 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:03 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:03 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:03 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:03 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:03 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:03 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:03 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:03 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:25:03 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:03 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:03 --> Total execution time: 0.0666
DEBUG - 2013-09-19 15:25:06 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:06 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:06 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:06 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:06 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:06 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:06 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:06 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:06 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:06 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 15:25:06 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:06 --> Total execution time: 0.1541
DEBUG - 2013-09-19 15:25:09 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:09 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:09 --> No URI present. Default controller set.
DEBUG - 2013-09-19 15:25:09 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:09 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:09 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:09 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:09 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:09 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:09 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:09 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:09 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:09 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:09 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:09 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:09 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:09 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:09 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 15:25:09 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 15:25:09 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:09 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:09 --> Total execution time: 0.0576
DEBUG - 2013-09-19 15:25:11 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:11 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:11 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:11 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:11 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:11 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:11 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:11 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:11 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:11 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:11 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:11 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:11 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:11 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:11 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:11 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:11 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:25:11 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:11 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:11 --> Total execution time: 0.0582
DEBUG - 2013-09-19 15:25:14 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:14 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:14 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:14 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:14 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:14 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:14 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:14 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:14 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:14 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:14 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:14 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:14 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:14 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:14 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:14 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:14 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:25:14 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:14 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:14 --> Total execution time: 0.0679
DEBUG - 2013-09-19 15:25:16 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:16 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:16 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:16 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:16 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:16 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:16 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:16 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:16 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:16 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:16 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:16 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:16 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:16 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:25:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:16 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:16 --> Total execution time: 0.0691
DEBUG - 2013-09-19 15:25:19 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:19 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:19 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:19 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:19 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:19 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:19 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:19 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:19 --> Helper loaded: email_helper
DEBUG - 2013-09-19 15:25:19 --> Helper loaded: form_helper
DEBUG - 2013-09-19 15:25:19 --> Form Validation Class Initialized
DEBUG - 2013-09-19 15:25:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:19 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:19 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:19 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 15:25:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:19 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:19 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 15:25:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:19 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:19 --> Total execution time: 0.0797
DEBUG - 2013-09-19 15:25:35 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:35 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:35 --> No URI present. Default controller set.
DEBUG - 2013-09-19 15:25:35 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:35 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:35 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:35 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:35 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:35 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:35 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:35 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:35 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:35 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:35 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:25:35 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:35 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:35 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:35 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 15:25:35 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 15:25:35 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:35 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:35 --> Total execution time: 0.0513
DEBUG - 2013-09-19 15:25:37 --> Config Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:25:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:25:37 --> URI Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Router Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Output Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Security Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Input Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:25:37 --> Language Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Loader Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:25:37 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:25:37 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Session Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:25:37 --> Session routines successfully run
DEBUG - 2013-09-19 15:25:37 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:25:37 --> Model Class Initialized
DEBUG - 2013-09-19 15:25:37 --> Controller Class Initialized
DEBUG - 2013-09-19 15:25:37 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:25:37 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:25:37 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:25:37 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:25:37 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:25:37 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:25:37 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:25:37 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:25:37 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:25:37 --> Final output sent to browser
DEBUG - 2013-09-19 15:25:37 --> Total execution time: 0.0515
DEBUG - 2013-09-19 15:26:22 --> Config Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:26:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:26:22 --> URI Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Router Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Output Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Security Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Input Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:26:22 --> Language Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Loader Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:26:22 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:26:22 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Session Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:26:22 --> Session routines successfully run
DEBUG - 2013-09-19 15:26:22 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:26:22 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:22 --> Controller Class Initialized
DEBUG - 2013-09-19 15:26:22 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:26:22 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:26:22 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:26:22 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:26:22 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:26:22 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:26:22 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:26:22 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:26:22 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:26:22 --> Final output sent to browser
DEBUG - 2013-09-19 15:26:22 --> Total execution time: 0.0413
DEBUG - 2013-09-19 15:26:25 --> Config Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:26:25 --> URI Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Router Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Output Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Security Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Input Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:26:25 --> Language Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Loader Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:26:25 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:26:25 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Session Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:26:25 --> Session routines successfully run
DEBUG - 2013-09-19 15:26:25 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:26:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:25 --> Controller Class Initialized
DEBUG - 2013-09-19 15:26:25 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 15:26:25 --> Final output sent to browser
DEBUG - 2013-09-19 15:26:25 --> Total execution time: 0.1806
DEBUG - 2013-09-19 15:26:49 --> Config Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:26:49 --> URI Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Router Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Output Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Security Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Input Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:26:49 --> Language Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Loader Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:26:49 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:26:49 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Session Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:26:49 --> Session routines successfully run
DEBUG - 2013-09-19 15:26:49 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:26:49 --> Model Class Initialized
DEBUG - 2013-09-19 15:26:49 --> Controller Class Initialized
DEBUG - 2013-09-19 15:26:49 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:26:49 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:26:49 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:26:49 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:26:49 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:26:49 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:26:49 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:26:49 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:26:49 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:26:49 --> Final output sent to browser
DEBUG - 2013-09-19 15:26:49 --> Total execution time: 0.0397
DEBUG - 2013-09-19 15:27:25 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:25 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:25 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:25 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:25 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:25 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:25 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:25 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:25 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:25 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:25 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:25 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:25 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:25 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:25 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:25 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:25 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:27:25 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:25 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:25 --> Total execution time: 0.0582
DEBUG - 2013-09-19 15:27:27 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:27 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:27 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:27 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:27 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:27 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:27 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:27 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:27 --> Helper loaded: email_helper
DEBUG - 2013-09-19 15:27:27 --> Helper loaded: form_helper
DEBUG - 2013-09-19 15:27:27 --> Form Validation Class Initialized
DEBUG - 2013-09-19 15:27:27 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:27 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:27 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:27 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:27 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 15:27:27 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:27 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:27 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 15:27:27 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:27 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:27 --> Total execution time: 0.0580
DEBUG - 2013-09-19 15:27:29 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:29 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:29 --> No URI present. Default controller set.
DEBUG - 2013-09-19 15:27:29 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:29 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:29 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:29 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:29 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:29 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:29 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:29 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:29 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:29 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:29 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:29 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:29 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:29 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:29 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 15:27:29 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 15:27:29 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:29 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:29 --> Total execution time: 0.0517
DEBUG - 2013-09-19 15:27:30 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:30 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:30 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:30 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:30 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:30 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:30 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:30 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:30 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:30 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:30 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:30 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:30 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:30 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:30 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:30 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:30 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:27:30 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:30 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:30 --> Total execution time: 0.0532
DEBUG - 2013-09-19 15:27:31 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:31 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:32 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:32 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:32 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:32 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:32 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:32 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:32 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:32 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:32 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:32 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:32 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:32 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:32 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:32 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:32 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:32 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:32 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:27:32 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:32 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:32 --> Total execution time: 0.0514
DEBUG - 2013-09-19 15:27:33 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:33 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:33 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:33 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:33 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:33 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:33 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:33 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:33 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:33 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:33 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:33 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:33 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:33 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:33 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:33 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:33 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:27:33 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:33 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:33 --> Total execution time: 0.0529
DEBUG - 2013-09-19 15:27:36 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:36 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:36 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:36 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:36 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:36 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:36 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:36 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:36 --> Helper loaded: email_helper
DEBUG - 2013-09-19 15:27:36 --> Helper loaded: form_helper
DEBUG - 2013-09-19 15:27:36 --> Form Validation Class Initialized
DEBUG - 2013-09-19 15:27:36 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:36 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:36 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:36 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:36 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 15:27:36 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:36 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:36 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 15:27:36 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:36 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:36 --> Total execution time: 0.0605
DEBUG - 2013-09-19 15:27:40 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:40 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:40 --> No URI present. Default controller set.
DEBUG - 2013-09-19 15:27:40 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:40 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:40 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:40 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:40 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:40 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:40 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:40 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:40 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:40 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:40 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:27:40 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:40 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:40 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:40 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 15:27:40 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 15:27:40 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:40 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:40 --> Total execution time: 0.0512
DEBUG - 2013-09-19 15:27:58 --> Config Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:27:58 --> URI Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Router Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Output Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Security Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Input Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:27:58 --> Language Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Loader Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:27:58 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:27:58 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Session Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:27:58 --> Session routines successfully run
DEBUG - 2013-09-19 15:27:58 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:27:58 --> Model Class Initialized
DEBUG - 2013-09-19 15:27:58 --> Controller Class Initialized
DEBUG - 2013-09-19 15:27:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:27:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:27:58 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:27:58 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:27:58 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:27:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:27:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:27:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:27:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:27:58 --> Final output sent to browser
DEBUG - 2013-09-19 15:27:58 --> Total execution time: 0.0517
DEBUG - 2013-09-19 15:28:42 --> Config Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:28:42 --> URI Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Router Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Output Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Security Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Input Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:28:42 --> Language Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Loader Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:28:42 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:28:42 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Session Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:28:42 --> Session routines successfully run
DEBUG - 2013-09-19 15:28:42 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:28:42 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:42 --> Controller Class Initialized
DEBUG - 2013-09-19 15:28:42 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:28:42 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:28:42 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:28:42 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 15:28:42 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 15:28:42 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:28:42 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:28:42 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 15:28:42 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:28:42 --> Final output sent to browser
DEBUG - 2013-09-19 15:28:42 --> Total execution time: 0.0516
DEBUG - 2013-09-19 15:28:47 --> Config Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Hooks Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Utf8 Class Initialized
DEBUG - 2013-09-19 15:28:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 15:28:47 --> URI Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Router Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Output Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Security Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Input Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 15:28:47 --> Language Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Loader Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 15:28:47 --> Helper loaded: url_helper
DEBUG - 2013-09-19 15:28:47 --> Database Driver Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Session Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Helper loaded: string_helper
DEBUG - 2013-09-19 15:28:47 --> Session routines successfully run
DEBUG - 2013-09-19 15:28:47 --> Pagination Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 15:28:47 --> Model Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Controller Class Initialized
DEBUG - 2013-09-19 15:28:47 --> Helper loaded: email_helper
DEBUG - 2013-09-19 15:28:47 --> Helper loaded: form_helper
DEBUG - 2013-09-19 15:28:47 --> Form Validation Class Initialized
DEBUG - 2013-09-19 15:28:47 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 15:28:47 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 15:28:47 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 15:28:47 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 15:28:47 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 15:28:47 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 15:28:47 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 15:28:47 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 15:28:47 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 15:28:47 --> Final output sent to browser
DEBUG - 2013-09-19 15:28:47 --> Total execution time: 0.0578
DEBUG - 2013-09-19 16:19:48 --> Config Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:19:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:19:48 --> URI Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Router Class Initialized
DEBUG - 2013-09-19 16:19:48 --> No URI present. Default controller set.
DEBUG - 2013-09-19 16:19:48 --> Output Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Security Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Input Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:19:48 --> Language Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Loader Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:19:48 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:19:48 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Session Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:19:48 --> A session cookie was not found.
DEBUG - 2013-09-19 16:19:48 --> Session routines successfully run
DEBUG - 2013-09-19 16:19:48 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Model Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Model Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:19:48 --> Model Class Initialized
DEBUG - 2013-09-19 16:19:48 --> Controller Class Initialized
DEBUG - 2013-09-19 16:19:48 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:19:48 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:19:48 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:19:48 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:19:48 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:19:48 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:19:48 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:19:48 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:19:48 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:19:48 --> Final output sent to browser
DEBUG - 2013-09-19 16:19:48 --> Total execution time: 0.0522
DEBUG - 2013-09-19 16:20:12 --> Config Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:20:12 --> URI Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Router Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Output Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Security Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Input Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:20:12 --> Language Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Loader Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:20:12 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:20:12 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Session Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:20:12 --> Session routines successfully run
DEBUG - 2013-09-19 16:20:12 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:20:12 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:12 --> Controller Class Initialized
DEBUG - 2013-09-19 16:20:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:20:12 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:20:12 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:20:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:20:12 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:20:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:20:12 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:20:12 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:20:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:20:12 --> Final output sent to browser
DEBUG - 2013-09-19 16:20:12 --> Total execution time: 0.0600
DEBUG - 2013-09-19 16:20:23 --> Config Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:20:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:20:23 --> URI Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Router Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Output Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Security Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Input Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:20:23 --> Language Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Loader Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:20:23 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:20:23 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Session Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:20:23 --> Session routines successfully run
DEBUG - 2013-09-19 16:20:23 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:20:23 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:23 --> Controller Class Initialized
DEBUG - 2013-09-19 16:20:23 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:20:23 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:20:23 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:20:23 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:20:23 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:20:23 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:20:23 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:20:23 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:20:23 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:20:23 --> Final output sent to browser
DEBUG - 2013-09-19 16:20:23 --> Total execution time: 0.0505
DEBUG - 2013-09-19 16:20:26 --> Config Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:20:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:20:26 --> URI Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Router Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Output Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Security Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Input Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:20:26 --> Language Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Loader Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:20:26 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:20:26 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Session Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:20:26 --> Session routines successfully run
DEBUG - 2013-09-19 16:20:26 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:20:26 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:26 --> Controller Class Initialized
DEBUG - 2013-09-19 16:20:26 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:20:26 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 16:20:26 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:20:26 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:20:26 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:20:26 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:20:26 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 16:20:26 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 16:20:26 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:20:26 --> Final output sent to browser
DEBUG - 2013-09-19 16:20:26 --> Total execution time: 0.0568
DEBUG - 2013-09-19 16:20:43 --> Config Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:20:43 --> URI Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Router Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Output Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Security Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Input Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:20:43 --> Language Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Loader Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:20:43 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:20:43 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Session Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:20:43 --> Session routines successfully run
DEBUG - 2013-09-19 16:20:43 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:20:43 --> Model Class Initialized
DEBUG - 2013-09-19 16:20:43 --> Controller Class Initialized
DEBUG - 2013-09-19 16:20:43 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 16:20:43 --> Final output sent to browser
DEBUG - 2013-09-19 16:20:43 --> Total execution time: 0.0773
DEBUG - 2013-09-19 16:21:19 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:19 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:19 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:19 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:19 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:19 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:19 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:19 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:19 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:19 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 16:21:19 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:19 --> Total execution time: 0.0544
DEBUG - 2013-09-19 16:21:24 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:24 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:24 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:24 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:24 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:24 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:24 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:24 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:24 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:24 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:24 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 16:21:24 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:21:24 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:24 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:24 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:24 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 16:21:24 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 16:21:24 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:24 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:24 --> Total execution time: 0.0536
DEBUG - 2013-09-19 16:21:27 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:27 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:27 --> No URI present. Default controller set.
DEBUG - 2013-09-19 16:21:27 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:27 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:27 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:27 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:27 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:27 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:27 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:27 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:27 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:27 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:21:27 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:21:27 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:27 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:27 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:27 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:21:27 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:21:27 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:27 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:27 --> Total execution time: 0.0484
DEBUG - 2013-09-19 16:21:29 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:29 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:29 --> No URI present. Default controller set.
DEBUG - 2013-09-19 16:21:29 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:29 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:29 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:29 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:29 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:29 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:29 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:29 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:29 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:29 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:21:29 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:21:29 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:29 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:29 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:29 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:21:29 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:21:29 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:29 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:29 --> Total execution time: 0.0511
DEBUG - 2013-09-19 16:21:31 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:31 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:31 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:31 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:31 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:31 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:31 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:31 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:31 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:31 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:31 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 16:21:31 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:21:31 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:31 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:31 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:31 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 16:21:31 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 16:21:31 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:31 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:31 --> Total execution time: 0.0533
DEBUG - 2013-09-19 16:21:34 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:34 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:34 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:34 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:34 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:34 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:34 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:34 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:34 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:34 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 16:21:34 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:21:34 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:34 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:34 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 16:21:34 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 16:21:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:34 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:34 --> Total execution time: 0.0497
DEBUG - 2013-09-19 16:21:40 --> Config Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:21:40 --> URI Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Router Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Output Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Security Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Input Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:21:40 --> Language Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Loader Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:21:40 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:21:40 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Session Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:21:40 --> Session routines successfully run
DEBUG - 2013-09-19 16:21:40 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:21:40 --> Model Class Initialized
DEBUG - 2013-09-19 16:21:40 --> Controller Class Initialized
DEBUG - 2013-09-19 16:21:40 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:21:40 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 16:21:40 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:21:40 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:21:40 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:21:40 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:21:40 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 16:21:40 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 16:21:40 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:21:40 --> Final output sent to browser
DEBUG - 2013-09-19 16:21:40 --> Total execution time: 0.0539
DEBUG - 2013-09-19 16:24:30 --> Config Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Hooks Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Utf8 Class Initialized
DEBUG - 2013-09-19 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 16:24:30 --> URI Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Router Class Initialized
DEBUG - 2013-09-19 16:24:30 --> No URI present. Default controller set.
DEBUG - 2013-09-19 16:24:30 --> Output Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Security Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Input Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 16:24:30 --> Language Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Loader Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 16:24:30 --> Helper loaded: url_helper
DEBUG - 2013-09-19 16:24:30 --> Database Driver Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Session Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Helper loaded: string_helper
DEBUG - 2013-09-19 16:24:30 --> Session routines successfully run
DEBUG - 2013-09-19 16:24:30 --> Pagination Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Model Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Model Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 16:24:30 --> Model Class Initialized
DEBUG - 2013-09-19 16:24:30 --> Controller Class Initialized
DEBUG - 2013-09-19 16:24:30 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 16:24:30 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 16:24:30 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 16:24:30 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 16:24:30 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 16:24:30 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 16:24:30 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 16:24:30 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 16:24:30 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 16:24:30 --> Final output sent to browser
DEBUG - 2013-09-19 16:24:30 --> Total execution time: 0.0524
DEBUG - 2013-09-19 20:22:11 --> Config Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Hooks Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Utf8 Class Initialized
DEBUG - 2013-09-19 20:22:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 20:22:11 --> URI Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Router Class Initialized
DEBUG - 2013-09-19 20:22:11 --> No URI present. Default controller set.
DEBUG - 2013-09-19 20:22:11 --> Output Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Security Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Input Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 20:22:11 --> Language Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Loader Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 20:22:11 --> Helper loaded: url_helper
DEBUG - 2013-09-19 20:22:11 --> Database Driver Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Session Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Helper loaded: string_helper
DEBUG - 2013-09-19 20:22:11 --> Session routines successfully run
DEBUG - 2013-09-19 20:22:11 --> Pagination Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 20:22:11 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:11 --> Controller Class Initialized
DEBUG - 2013-09-19 20:22:11 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 20:22:11 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 20:22:11 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 20:22:11 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 20:22:11 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 20:22:11 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 20:22:11 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 20:22:11 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 20:22:11 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 20:22:11 --> Final output sent to browser
DEBUG - 2013-09-19 20:22:11 --> Total execution time: 0.1539
DEBUG - 2013-09-19 20:22:16 --> Config Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Hooks Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Utf8 Class Initialized
DEBUG - 2013-09-19 20:22:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 20:22:16 --> URI Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Router Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Output Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Security Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Input Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 20:22:16 --> Language Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Loader Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 20:22:16 --> Helper loaded: url_helper
DEBUG - 2013-09-19 20:22:16 --> Database Driver Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Session Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Helper loaded: string_helper
DEBUG - 2013-09-19 20:22:16 --> Session routines successfully run
DEBUG - 2013-09-19 20:22:16 --> Pagination Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 20:22:16 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:16 --> Controller Class Initialized
DEBUG - 2013-09-19 20:22:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 20:22:16 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 20:22:16 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 20:22:16 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 20:22:16 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 20:22:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 20:22:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 20:22:16 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 20:22:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 20:22:16 --> Final output sent to browser
DEBUG - 2013-09-19 20:22:16 --> Total execution time: 0.0756
DEBUG - 2013-09-19 20:22:17 --> Config Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Hooks Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Utf8 Class Initialized
DEBUG - 2013-09-19 20:22:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 20:22:17 --> URI Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Router Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Output Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Security Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Input Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 20:22:17 --> Language Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Loader Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 20:22:17 --> Helper loaded: url_helper
DEBUG - 2013-09-19 20:22:17 --> Database Driver Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Session Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Helper loaded: string_helper
DEBUG - 2013-09-19 20:22:17 --> Session routines successfully run
DEBUG - 2013-09-19 20:22:17 --> Pagination Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 20:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:17 --> Controller Class Initialized
DEBUG - 2013-09-19 20:22:17 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 20:22:17 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 20:22:17 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 20:22:17 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 20:22:17 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 20:22:17 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 20:22:17 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 20:22:17 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 20:22:17 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 20:22:17 --> Final output sent to browser
DEBUG - 2013-09-19 20:22:17 --> Total execution time: 0.0692
DEBUG - 2013-09-19 20:22:20 --> Config Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Hooks Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Utf8 Class Initialized
DEBUG - 2013-09-19 20:22:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 20:22:20 --> URI Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Router Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Output Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Security Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Input Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 20:22:20 --> Language Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Loader Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 20:22:20 --> Helper loaded: url_helper
DEBUG - 2013-09-19 20:22:20 --> Database Driver Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Session Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Helper loaded: string_helper
DEBUG - 2013-09-19 20:22:20 --> Session routines successfully run
DEBUG - 2013-09-19 20:22:20 --> Pagination Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 20:22:20 --> Model Class Initialized
DEBUG - 2013-09-19 20:22:20 --> Controller Class Initialized
DEBUG - 2013-09-19 20:22:20 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 20:22:21 --> Final output sent to browser
DEBUG - 2013-09-19 20:22:21 --> Total execution time: 0.2168
DEBUG - 2013-09-19 21:32:26 --> Config Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Hooks Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Utf8 Class Initialized
DEBUG - 2013-09-19 21:32:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 21:32:26 --> URI Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Router Class Initialized
DEBUG - 2013-09-19 21:32:26 --> No URI present. Default controller set.
DEBUG - 2013-09-19 21:32:26 --> Output Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Security Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Input Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 21:32:26 --> Language Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Loader Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 21:32:26 --> Helper loaded: url_helper
DEBUG - 2013-09-19 21:32:26 --> Database Driver Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Session Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Helper loaded: string_helper
DEBUG - 2013-09-19 21:32:26 --> A session cookie was not found.
DEBUG - 2013-09-19 21:32:26 --> Session routines successfully run
DEBUG - 2013-09-19 21:32:26 --> Pagination Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 21:32:26 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:26 --> Controller Class Initialized
DEBUG - 2013-09-19 21:32:26 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 21:32:26 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 21:32:26 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 21:32:26 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 21:32:26 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 21:32:26 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 21:32:26 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 21:32:26 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 21:32:26 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 21:32:26 --> Final output sent to browser
DEBUG - 2013-09-19 21:32:26 --> Total execution time: 0.0544
DEBUG - 2013-09-19 21:32:51 --> Config Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Hooks Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Utf8 Class Initialized
DEBUG - 2013-09-19 21:32:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 21:32:51 --> URI Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Router Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Output Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Security Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Input Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 21:32:51 --> Language Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Loader Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 21:32:51 --> Helper loaded: url_helper
DEBUG - 2013-09-19 21:32:51 --> Database Driver Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Session Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Helper loaded: string_helper
DEBUG - 2013-09-19 21:32:51 --> Session routines successfully run
DEBUG - 2013-09-19 21:32:51 --> Pagination Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 21:32:51 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:51 --> Controller Class Initialized
DEBUG - 2013-09-19 21:32:51 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 21:32:51 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 21:32:51 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 21:32:51 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 21:32:51 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 21:32:51 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 21:32:51 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 21:32:51 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 21:32:51 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 21:32:51 --> Final output sent to browser
DEBUG - 2013-09-19 21:32:51 --> Total execution time: 0.0536
DEBUG - 2013-09-19 21:32:54 --> Config Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Hooks Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Utf8 Class Initialized
DEBUG - 2013-09-19 21:32:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 21:32:54 --> URI Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Router Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Output Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Security Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Input Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 21:32:54 --> Language Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Loader Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 21:32:54 --> Helper loaded: url_helper
DEBUG - 2013-09-19 21:32:54 --> Database Driver Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Session Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Helper loaded: string_helper
DEBUG - 2013-09-19 21:32:54 --> Session routines successfully run
DEBUG - 2013-09-19 21:32:54 --> Pagination Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 21:32:54 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:54 --> Controller Class Initialized
DEBUG - 2013-09-19 21:32:54 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-19 21:32:54 --> Final output sent to browser
DEBUG - 2013-09-19 21:32:54 --> Total execution time: 0.1314
DEBUG - 2013-09-19 21:32:58 --> Config Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Hooks Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Utf8 Class Initialized
DEBUG - 2013-09-19 21:32:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 21:32:58 --> URI Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Router Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Output Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Security Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Input Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 21:32:58 --> Language Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Loader Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 21:32:58 --> Helper loaded: url_helper
DEBUG - 2013-09-19 21:32:58 --> Database Driver Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Session Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Helper loaded: string_helper
DEBUG - 2013-09-19 21:32:58 --> Session routines successfully run
DEBUG - 2013-09-19 21:32:58 --> Pagination Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 21:32:58 --> Model Class Initialized
DEBUG - 2013-09-19 21:32:58 --> Controller Class Initialized
DEBUG - 2013-09-19 21:32:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 21:32:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 21:32:58 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 21:32:58 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 21:32:58 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 21:32:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 21:32:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 21:32:58 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-19 21:32:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 21:32:58 --> Final output sent to browser
DEBUG - 2013-09-19 21:32:58 --> Total execution time: 0.0581
DEBUG - 2013-09-19 23:21:26 --> Config Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Hooks Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Utf8 Class Initialized
DEBUG - 2013-09-19 23:21:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 23:21:26 --> URI Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Router Class Initialized
DEBUG - 2013-09-19 23:21:26 --> No URI present. Default controller set.
DEBUG - 2013-09-19 23:21:26 --> Output Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Security Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Input Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 23:21:26 --> Language Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Loader Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 23:21:26 --> Helper loaded: url_helper
DEBUG - 2013-09-19 23:21:26 --> Database Driver Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Session Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Helper loaded: string_helper
DEBUG - 2013-09-19 23:21:26 --> A session cookie was not found.
DEBUG - 2013-09-19 23:21:26 --> Session routines successfully run
DEBUG - 2013-09-19 23:21:26 --> Pagination Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 23:21:26 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:26 --> Controller Class Initialized
DEBUG - 2013-09-19 23:21:26 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 23:21:26 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 23:21:26 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 23:21:26 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-19 23:21:26 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-19 23:21:26 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 23:21:26 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-19 23:21:26 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-19 23:21:26 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 23:21:26 --> Final output sent to browser
DEBUG - 2013-09-19 23:21:26 --> Total execution time: 0.0531
DEBUG - 2013-09-19 23:21:47 --> Config Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Hooks Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Utf8 Class Initialized
DEBUG - 2013-09-19 23:21:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 23:21:47 --> URI Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Router Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Output Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Security Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Input Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 23:21:47 --> Language Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Loader Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 23:21:47 --> Helper loaded: url_helper
DEBUG - 2013-09-19 23:21:47 --> Database Driver Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Session Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Helper loaded: string_helper
DEBUG - 2013-09-19 23:21:47 --> Session routines successfully run
DEBUG - 2013-09-19 23:21:47 --> Pagination Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 23:21:47 --> Model Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Controller Class Initialized
DEBUG - 2013-09-19 23:21:47 --> Helper loaded: email_helper
DEBUG - 2013-09-19 23:21:47 --> Helper loaded: form_helper
DEBUG - 2013-09-19 23:21:47 --> Form Validation Class Initialized
DEBUG - 2013-09-19 23:21:47 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 23:21:47 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 23:21:47 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 23:21:47 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 23:21:47 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 23:21:47 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 23:21:47 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 23:21:47 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-19 23:21:47 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 23:21:47 --> Final output sent to browser
DEBUG - 2013-09-19 23:21:47 --> Total execution time: 0.0831
DEBUG - 2013-09-19 23:22:17 --> Config Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Hooks Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Utf8 Class Initialized
DEBUG - 2013-09-19 23:22:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-19 23:22:17 --> URI Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Router Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Output Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Security Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Input Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-19 23:22:17 --> Language Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Loader Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-19 23:22:17 --> Helper loaded: url_helper
DEBUG - 2013-09-19 23:22:17 --> Database Driver Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Session Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Helper loaded: string_helper
DEBUG - 2013-09-19 23:22:17 --> Session routines successfully run
DEBUG - 2013-09-19 23:22:17 --> Pagination Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-19 23:22:17 --> Model Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Controller Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Helper loaded: email_helper
DEBUG - 2013-09-19 23:22:17 --> Helper loaded: form_helper
DEBUG - 2013-09-19 23:22:17 --> Form Validation Class Initialized
DEBUG - 2013-09-19 23:22:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> XSS Filtering completed
DEBUG - 2013-09-19 23:22:17 --> File loaded: appweb/views/header.php
ERROR - 2013-09-19 23:22:17 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-19 23:22:17 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-19 23:22:17 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-19 23:22:17 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-19 23:22:17 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-19 23:22:17 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-19 23:22:17 --> File loaded: appweb/views/recibido.php
DEBUG - 2013-09-19 23:22:17 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-19 23:22:17 --> Final output sent to browser
DEBUG - 2013-09-19 23:22:17 --> Total execution time: 0.3476
