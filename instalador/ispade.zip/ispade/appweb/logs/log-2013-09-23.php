<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-23 13:42:06 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:06 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:06 --> No URI present. Default controller set.
DEBUG - 2013-09-23 13:42:06 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:06 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:06 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:06 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:06 --> A session cookie was not found.
DEBUG - 2013-09-23 13:42:06 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:06 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:06 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:06 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:06 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:06 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:42:06 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:42:06 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:42:06 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:42:06 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:06 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 13:42:06 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 13:42:06 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:06 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:06 --> Total execution time: 0.1211
DEBUG - 2013-09-23 13:42:12 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:12 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:12 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:12 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:12 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:12 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:12 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:12 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:12 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:12 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:42:12 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:42:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:42:12 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:42:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:12 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:42:12 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:42:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:12 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:12 --> Total execution time: 0.0247
DEBUG - 2013-09-23 13:42:14 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:14 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:14 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:14 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:14 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:14 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:14 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:14 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:14 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 13:42:14 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:14 --> Total execution time: 0.1865
DEBUG - 2013-09-23 13:42:20 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:20 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:20 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:20 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:20 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:20 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:20 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:20 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:20 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:20 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:20 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:42:20 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:42:20 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:42:20 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:42:20 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:20 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:42:20 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:42:20 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:20 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:20 --> Total execution time: 0.0589
DEBUG - 2013-09-23 13:42:23 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:23 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:23 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:23 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:23 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:23 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:23 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:23 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:23 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 13:42:23 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:23 --> Total execution time: 0.1389
DEBUG - 2013-09-23 13:42:27 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:27 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:27 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:27 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:27 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:27 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:27 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:27 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:27 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:27 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:27 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:42:27 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:42:27 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:42:27 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:42:27 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:27 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:42:27 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:42:27 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:27 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:27 --> Total execution time: 0.0578
DEBUG - 2013-09-23 13:42:30 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:30 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:30 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:30 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:30 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:30 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:30 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:30 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:30 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:30 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 13:42:30 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:30 --> Total execution time: 0.0410
DEBUG - 2013-09-23 13:42:35 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:35 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:35 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:35 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:35 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:35 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:35 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:35 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:35 --> Helper loaded: email_helper
DEBUG - 2013-09-23 13:42:35 --> Helper loaded: form_helper
DEBUG - 2013-09-23 13:42:35 --> Form Validation Class Initialized
DEBUG - 2013-09-23 13:42:35 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:35 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:42:35 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:42:35 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:42:35 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-23 13:42:35 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:35 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:42:35 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-23 13:42:35 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:35 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:35 --> Total execution time: 0.0754
DEBUG - 2013-09-23 13:42:58 --> Config Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:42:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:42:58 --> URI Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Router Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Output Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Security Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Input Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:42:58 --> Language Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Loader Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:42:58 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:42:58 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Session Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:42:58 --> A session cookie was not found.
DEBUG - 2013-09-23 13:42:58 --> Session routines successfully run
DEBUG - 2013-09-23 13:42:58 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:42:58 --> Model Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Controller Class Initialized
DEBUG - 2013-09-23 13:42:58 --> Helper loaded: email_helper
DEBUG - 2013-09-23 13:42:58 --> Helper loaded: form_helper
DEBUG - 2013-09-23 13:42:58 --> Form Validation Class Initialized
DEBUG - 2013-09-23 13:42:58 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:42:58 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:42:58 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:42:58 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:42:58 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-23 13:42:58 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:42:58 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:42:58 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-23 13:42:58 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:42:58 --> Final output sent to browser
DEBUG - 2013-09-23 13:42:58 --> Total execution time: 0.0405
DEBUG - 2013-09-23 13:43:07 --> Config Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:43:07 --> URI Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Router Class Initialized
DEBUG - 2013-09-23 13:43:07 --> No URI present. Default controller set.
DEBUG - 2013-09-23 13:43:07 --> Output Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Security Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Input Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:43:07 --> Language Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Loader Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:43:07 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:43:07 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Session Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:43:07 --> Session routines successfully run
DEBUG - 2013-09-23 13:43:07 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:43:07 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:07 --> Controller Class Initialized
DEBUG - 2013-09-23 13:43:07 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:43:07 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:43:07 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:43:07 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:43:07 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:43:07 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:43:07 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 13:43:07 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 13:43:07 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:43:07 --> Final output sent to browser
DEBUG - 2013-09-23 13:43:07 --> Total execution time: 0.0272
DEBUG - 2013-09-23 13:43:14 --> Config Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:43:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:43:14 --> URI Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Router Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Output Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Security Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Input Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:43:14 --> Language Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Loader Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:43:14 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:43:14 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Session Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:43:14 --> Session routines successfully run
DEBUG - 2013-09-23 13:43:14 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:43:14 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:14 --> Controller Class Initialized
DEBUG - 2013-09-23 13:43:14 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:43:14 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:43:14 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:43:14 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:43:14 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:43:14 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:43:14 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:43:14 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:43:14 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:43:14 --> Final output sent to browser
DEBUG - 2013-09-23 13:43:14 --> Total execution time: 0.0348
DEBUG - 2013-09-23 13:43:19 --> Config Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:43:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:43:19 --> URI Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Router Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Output Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Security Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Input Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:43:19 --> Language Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Loader Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:43:19 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:43:19 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Session Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:43:19 --> Session routines successfully run
DEBUG - 2013-09-23 13:43:19 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:43:19 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:19 --> Controller Class Initialized
DEBUG - 2013-09-23 13:43:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:43:19 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:43:19 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:43:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 13:43:19 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:43:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:43:19 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:43:19 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:43:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:43:19 --> Final output sent to browser
DEBUG - 2013-09-23 13:43:19 --> Total execution time: 0.0357
DEBUG - 2013-09-23 13:43:21 --> Config Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:43:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:43:21 --> URI Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Router Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Output Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Security Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Input Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:43:21 --> Language Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Loader Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:43:21 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:43:21 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Session Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:43:21 --> Session routines successfully run
DEBUG - 2013-09-23 13:43:21 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:21 --> Controller Class Initialized
DEBUG - 2013-09-23 13:43:21 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 13:43:21 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 13:43:21 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 13:43:21 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 13:43:21 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 13:43:21 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 13:43:21 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 13:43:21 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 13:43:21 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 13:43:21 --> Final output sent to browser
DEBUG - 2013-09-23 13:43:21 --> Total execution time: 0.0376
DEBUG - 2013-09-23 13:43:23 --> Config Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Hooks Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Utf8 Class Initialized
DEBUG - 2013-09-23 13:43:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 13:43:23 --> URI Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Router Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Output Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Security Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Input Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 13:43:23 --> Language Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Loader Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 13:43:23 --> Helper loaded: url_helper
DEBUG - 2013-09-23 13:43:23 --> Database Driver Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Session Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Helper loaded: string_helper
DEBUG - 2013-09-23 13:43:23 --> Session routines successfully run
DEBUG - 2013-09-23 13:43:23 --> Pagination Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 13:43:23 --> Model Class Initialized
DEBUG - 2013-09-23 13:43:23 --> Controller Class Initialized
DEBUG - 2013-09-23 13:43:23 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 13:43:23 --> Final output sent to browser
DEBUG - 2013-09-23 13:43:23 --> Total execution time: 0.0764
DEBUG - 2013-09-23 18:29:35 --> Config Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:29:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:29:35 --> URI Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Router Class Initialized
DEBUG - 2013-09-23 18:29:35 --> No URI present. Default controller set.
DEBUG - 2013-09-23 18:29:35 --> Output Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Security Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Input Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:29:35 --> Language Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Loader Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:29:35 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:29:35 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Session Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:29:35 --> A session cookie was not found.
DEBUG - 2013-09-23 18:29:35 --> Session routines successfully run
DEBUG - 2013-09-23 18:29:35 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:29:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:29:35 --> Controller Class Initialized
DEBUG - 2013-09-23 18:29:35 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:29:35 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:29:35 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:29:35 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:29:35 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:29:35 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:29:35 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 18:29:35 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 18:29:35 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:29:35 --> Final output sent to browser
DEBUG - 2013-09-23 18:29:35 --> Total execution time: 0.0303
DEBUG - 2013-09-23 18:30:30 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:30 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:30 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:30 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:30 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:30 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:30 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:30 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:30 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:30 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:30:30 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:30:30 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:30:30 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:30:30 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:30:30 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:30:30 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:30:30 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:30:30 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:30:30 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:30 --> Total execution time: 0.0517
DEBUG - 2013-09-23 18:30:31 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:31 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:31 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:31 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:31 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:31 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:31 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:31 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:31 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:31 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:30:31 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:31 --> Total execution time: 0.0419
DEBUG - 2013-09-23 18:30:34 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:34 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:34 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:34 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:34 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:34 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:34 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:34 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:30:34 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:30:34 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:30:34 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:30:34 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:30:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:30:34 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:30:34 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:30:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:30:34 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:34 --> Total execution time: 0.0239
DEBUG - 2013-09-23 18:30:35 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:35 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:35 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:35 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:35 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:35 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:35 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:35 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:35 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:35 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:30:35 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:35 --> Total execution time: 0.0405
DEBUG - 2013-09-23 18:30:40 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:40 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:40 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:40 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:40 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:40 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:40 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:40 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:40 --> Helper loaded: email_helper
DEBUG - 2013-09-23 18:30:40 --> Helper loaded: form_helper
DEBUG - 2013-09-23 18:30:40 --> Form Validation Class Initialized
DEBUG - 2013-09-23 18:30:40 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:30:40 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:30:40 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:30:40 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:30:40 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-23 18:30:40 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:30:40 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:30:40 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-23 18:30:40 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:30:40 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:40 --> Total execution time: 0.0266
DEBUG - 2013-09-23 18:30:59 --> Config Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:30:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:30:59 --> URI Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Router Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Output Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Security Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Input Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:30:59 --> Language Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Loader Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:30:59 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:30:59 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Session Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:30:59 --> Session routines successfully run
DEBUG - 2013-09-23 18:30:59 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:30:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:30:59 --> Controller Class Initialized
DEBUG - 2013-09-23 18:30:59 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:30:59 --> Final output sent to browser
DEBUG - 2013-09-23 18:30:59 --> Total execution time: 0.0392
DEBUG - 2013-09-23 18:31:02 --> Config Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:31:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:31:02 --> URI Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Router Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Output Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Security Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Input Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:31:02 --> Language Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Loader Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:31:02 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:31:02 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Session Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:31:02 --> Session routines successfully run
DEBUG - 2013-09-23 18:31:02 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:31:02 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:02 --> Controller Class Initialized
DEBUG - 2013-09-23 18:31:02 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:31:02 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:31:02 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:31:02 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:31:02 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:31:02 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:31:02 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:31:02 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:31:02 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:31:02 --> Final output sent to browser
DEBUG - 2013-09-23 18:31:02 --> Total execution time: 0.0307
DEBUG - 2013-09-23 18:31:04 --> Config Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:31:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:31:04 --> URI Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Router Class Initialized
DEBUG - 2013-09-23 18:31:04 --> No URI present. Default controller set.
DEBUG - 2013-09-23 18:31:04 --> Output Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Security Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Input Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:31:04 --> Language Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Loader Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:31:04 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:31:04 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Session Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:31:04 --> Session routines successfully run
DEBUG - 2013-09-23 18:31:04 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:31:04 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:04 --> Controller Class Initialized
DEBUG - 2013-09-23 18:31:04 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:31:04 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:31:04 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:31:04 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:31:04 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:31:04 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:31:04 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 18:31:04 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 18:31:04 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:31:04 --> Final output sent to browser
DEBUG - 2013-09-23 18:31:04 --> Total execution time: 0.0239
DEBUG - 2013-09-23 18:31:10 --> Config Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:31:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:31:10 --> URI Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Router Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Output Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Security Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Input Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:31:10 --> Language Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Loader Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:31:10 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:31:10 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Session Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:31:10 --> Session routines successfully run
DEBUG - 2013-09-23 18:31:10 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:31:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:31:10 --> Controller Class Initialized
DEBUG - 2013-09-23 18:31:10 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:31:10 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:31:10 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:31:10 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:31:10 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:31:10 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:31:10 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:31:10 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:31:10 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:31:10 --> Final output sent to browser
DEBUG - 2013-09-23 18:31:10 --> Total execution time: 0.0241
DEBUG - 2013-09-23 18:40:43 --> Config Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:40:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:40:43 --> URI Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Router Class Initialized
DEBUG - 2013-09-23 18:40:43 --> No URI present. Default controller set.
DEBUG - 2013-09-23 18:40:43 --> Output Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Security Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Input Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:40:43 --> Language Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Loader Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:40:43 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:40:43 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Session Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:40:43 --> A session cookie was not found.
DEBUG - 2013-09-23 18:40:43 --> Session routines successfully run
DEBUG - 2013-09-23 18:40:43 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Model Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Model Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:40:43 --> Model Class Initialized
DEBUG - 2013-09-23 18:40:43 --> Controller Class Initialized
DEBUG - 2013-09-23 18:40:43 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:40:43 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:40:43 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:40:43 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:40:43 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:40:43 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:40:43 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 18:40:43 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 18:40:43 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:40:43 --> Final output sent to browser
DEBUG - 2013-09-23 18:40:43 --> Total execution time: 0.0522
DEBUG - 2013-09-23 18:41:46 --> Config Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:41:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:41:46 --> URI Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Router Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Output Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Security Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Input Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:41:46 --> Language Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Loader Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:41:46 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:41:46 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Session Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:41:46 --> Session routines successfully run
DEBUG - 2013-09-23 18:41:46 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:41:46 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:46 --> Controller Class Initialized
DEBUG - 2013-09-23 18:41:46 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:41:46 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:41:46 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:41:46 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:41:46 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:41:46 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:41:46 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:41:46 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:41:46 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:41:46 --> Final output sent to browser
DEBUG - 2013-09-23 18:41:46 --> Total execution time: 0.0263
DEBUG - 2013-09-23 18:41:50 --> Config Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:41:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:41:50 --> URI Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Router Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Output Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Security Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Input Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:41:50 --> Language Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Loader Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:41:50 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:41:50 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Session Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:41:50 --> Session routines successfully run
DEBUG - 2013-09-23 18:41:50 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:41:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:50 --> Controller Class Initialized
DEBUG - 2013-09-23 18:41:50 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:41:50 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:41:50 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:41:50 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:41:50 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:41:50 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:41:50 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:41:50 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:41:50 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:41:50 --> Final output sent to browser
DEBUG - 2013-09-23 18:41:50 --> Total execution time: 0.0243
DEBUG - 2013-09-23 18:41:53 --> Config Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:41:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:41:53 --> URI Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Router Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Output Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Security Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Input Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:41:53 --> Language Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Loader Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:41:53 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:41:53 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Session Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:41:53 --> Session routines successfully run
DEBUG - 2013-09-23 18:41:53 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:41:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:41:53 --> Controller Class Initialized
DEBUG - 2013-09-23 18:41:53 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:41:53 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:41:53 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:41:53 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:41:53 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:41:53 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:41:53 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:41:53 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:41:53 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:41:53 --> Final output sent to browser
DEBUG - 2013-09-23 18:41:53 --> Total execution time: 0.0552
DEBUG - 2013-09-23 18:42:01 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:01 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:01 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:01 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:01 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:01 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:01 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:01 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:01 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:01 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:42:01 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:42:01 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:42:01 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:42:01 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:42:01 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:42:01 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:42:01 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:42:01 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:42:01 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:01 --> Total execution time: 0.0566
DEBUG - 2013-09-23 18:42:11 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:11 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:11 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:11 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:11 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:11 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:11 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:11 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:11 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:11 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:42:11 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:42:11 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:42:11 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:42:11 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:42:11 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:42:11 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:42:11 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:42:11 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:42:11 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:11 --> Total execution time: 0.0367
DEBUG - 2013-09-23 18:42:14 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:14 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:14 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:14 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:14 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:14 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:14 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:15 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:15 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:15 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:15 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:15 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:15 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:42:15 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:15 --> Total execution time: 0.0580
DEBUG - 2013-09-23 18:42:24 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:24 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:24 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:24 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:24 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:24 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:24 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:24 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:24 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:24 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:42:24 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:24 --> Total execution time: 0.0539
DEBUG - 2013-09-23 18:42:28 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:28 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:28 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:28 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:28 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:28 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:28 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:28 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:28 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:28 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:42:28 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:28 --> Total execution time: 0.0726
DEBUG - 2013-09-23 18:42:50 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:50 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:50 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:50 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:50 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:50 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:50 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:50 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:50 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:50 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:42:50 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:42:50 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:42:50 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:42:50 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:42:50 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:42:50 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:42:50 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:42:50 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:42:50 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:50 --> Total execution time: 0.0255
DEBUG - 2013-09-23 18:42:51 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:51 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:51 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:51 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:51 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:51 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:51 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:51 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:51 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:51 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:42:51 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:51 --> Total execution time: 0.0483
DEBUG - 2013-09-23 18:42:56 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:56 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:56 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:56 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:56 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:56 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:56 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:56 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:56 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:42:56 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:42:56 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:42:56 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:42:56 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:42:56 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:42:56 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:42:56 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:42:56 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:42:56 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:56 --> Total execution time: 0.0246
DEBUG - 2013-09-23 18:42:59 --> Config Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:42:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:42:59 --> URI Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Router Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Output Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Security Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Input Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:42:59 --> Language Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Loader Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:42:59 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:42:59 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Session Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:42:59 --> Session routines successfully run
DEBUG - 2013-09-23 18:42:59 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:42:59 --> Model Class Initialized
DEBUG - 2013-09-23 18:42:59 --> Controller Class Initialized
DEBUG - 2013-09-23 18:42:59 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:42:59 --> Final output sent to browser
DEBUG - 2013-09-23 18:42:59 --> Total execution time: 0.0331
DEBUG - 2013-09-23 18:43:03 --> Config Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:43:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:43:03 --> URI Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Router Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Output Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Security Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Input Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:43:03 --> Language Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Loader Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:43:03 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:43:03 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Session Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:43:03 --> Session routines successfully run
DEBUG - 2013-09-23 18:43:03 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:43:03 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Controller Class Initialized
DEBUG - 2013-09-23 18:43:03 --> Helper loaded: email_helper
DEBUG - 2013-09-23 18:43:03 --> Helper loaded: form_helper
DEBUG - 2013-09-23 18:43:03 --> Form Validation Class Initialized
DEBUG - 2013-09-23 18:43:03 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:43:03 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:43:03 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:43:03 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:43:03 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-23 18:43:03 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:43:03 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:43:03 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-23 18:43:03 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:43:03 --> Final output sent to browser
DEBUG - 2013-09-23 18:43:03 --> Total execution time: 0.0565
DEBUG - 2013-09-23 18:43:10 --> Config Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:43:10 --> URI Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Router Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Output Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Security Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Input Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:43:10 --> Language Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Loader Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:43:10 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:43:10 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Session Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:43:10 --> Session routines successfully run
DEBUG - 2013-09-23 18:43:10 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:43:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:10 --> Controller Class Initialized
DEBUG - 2013-09-23 18:43:10 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:43:10 --> Final output sent to browser
DEBUG - 2013-09-23 18:43:10 --> Total execution time: 0.0481
DEBUG - 2013-09-23 18:43:13 --> Config Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:43:13 --> URI Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Router Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Output Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Security Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Input Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:43:13 --> Language Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Loader Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:43:13 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:43:13 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Session Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:43:13 --> Session routines successfully run
DEBUG - 2013-09-23 18:43:13 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:43:13 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:13 --> Controller Class Initialized
DEBUG - 2013-09-23 18:43:13 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:43:13 --> Final output sent to browser
DEBUG - 2013-09-23 18:43:13 --> Total execution time: 0.0354
DEBUG - 2013-09-23 18:43:21 --> Config Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:43:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:43:21 --> URI Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Router Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Output Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Security Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Input Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:43:21 --> Language Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Loader Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:43:21 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:43:21 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Session Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:43:21 --> Session routines successfully run
DEBUG - 2013-09-23 18:43:21 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:43:21 --> Model Class Initialized
DEBUG - 2013-09-23 18:43:21 --> Controller Class Initialized
DEBUG - 2013-09-23 18:43:21 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:43:21 --> Final output sent to browser
DEBUG - 2013-09-23 18:43:21 --> Total execution time: 0.0280
DEBUG - 2013-09-23 18:44:12 --> Config Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:44:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:44:12 --> URI Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Router Class Initialized
DEBUG - 2013-09-23 18:44:12 --> No URI present. Default controller set.
DEBUG - 2013-09-23 18:44:12 --> Output Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Security Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Input Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:44:12 --> Language Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Loader Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:44:12 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:44:12 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Session Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:44:12 --> Session routines successfully run
DEBUG - 2013-09-23 18:44:12 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:44:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:12 --> Controller Class Initialized
DEBUG - 2013-09-23 18:44:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:44:12 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:44:12 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:44:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:44:12 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:44:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:44:12 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 18:44:12 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 18:44:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:44:12 --> Final output sent to browser
DEBUG - 2013-09-23 18:44:12 --> Total execution time: 0.0248
DEBUG - 2013-09-23 18:44:34 --> Config Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:44:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:44:34 --> URI Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Router Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Output Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Security Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Input Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:44:34 --> Language Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Loader Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:44:34 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:44:34 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Session Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:44:34 --> Session routines successfully run
DEBUG - 2013-09-23 18:44:34 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:44:34 --> Model Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Controller Class Initialized
DEBUG - 2013-09-23 18:44:34 --> Helper loaded: email_helper
DEBUG - 2013-09-23 18:44:34 --> Helper loaded: form_helper
DEBUG - 2013-09-23 18:44:34 --> Form Validation Class Initialized
DEBUG - 2013-09-23 18:44:34 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:44:34 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:44:34 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:44:34 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:44:34 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
DEBUG - 2013-09-23 18:44:34 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:44:34 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:44:34 --> File loaded: appweb/views/form.php
DEBUG - 2013-09-23 18:44:34 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:44:34 --> Final output sent to browser
DEBUG - 2013-09-23 18:44:34 --> Total execution time: 0.0451
DEBUG - 2013-09-23 18:45:53 --> Config Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:45:53 --> URI Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Router Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Output Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Security Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Input Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:45:53 --> Language Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Loader Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:45:53 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:45:53 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Session Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:45:53 --> Session routines successfully run
DEBUG - 2013-09-23 18:45:53 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:45:53 --> Model Class Initialized
DEBUG - 2013-09-23 18:45:53 --> Controller Class Initialized
DEBUG - 2013-09-23 18:45:53 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:45:53 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:45:53 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:45:53 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:45:53 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:45:53 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:45:53 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:45:53 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:45:53 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:45:53 --> Final output sent to browser
DEBUG - 2013-09-23 18:45:53 --> Total execution time: 0.0291
DEBUG - 2013-09-23 18:46:12 --> Config Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:46:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:46:12 --> URI Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Router Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Output Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Security Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Input Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:46:12 --> Language Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Loader Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:46:12 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:46:12 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Session Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:46:12 --> Session routines successfully run
DEBUG - 2013-09-23 18:46:12 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:46:12 --> Model Class Initialized
DEBUG - 2013-09-23 18:46:12 --> Controller Class Initialized
DEBUG - 2013-09-23 18:46:12 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:46:12 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:46:12 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:46:12 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:46:12 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:46:12 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:46:12 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:46:12 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:46:12 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:46:12 --> Final output sent to browser
DEBUG - 2013-09-23 18:46:12 --> Total execution time: 0.0534
DEBUG - 2013-09-23 18:48:05 --> Config Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:48:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:48:05 --> URI Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Router Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Output Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Security Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Input Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:48:05 --> Language Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Loader Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:48:05 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:48:05 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Session Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:48:05 --> Session routines successfully run
DEBUG - 2013-09-23 18:48:05 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:48:05 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:05 --> Controller Class Initialized
DEBUG - 2013-09-23 18:48:05 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:48:05 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:48:05 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:48:05 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:48:05 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:48:05 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:48:05 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:48:05 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:48:05 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:48:05 --> Final output sent to browser
DEBUG - 2013-09-23 18:48:05 --> Total execution time: 0.0252
DEBUG - 2013-09-23 18:48:10 --> Config Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:48:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:48:10 --> URI Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Router Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Output Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Security Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Input Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:48:10 --> Language Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Loader Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:48:10 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:48:10 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Session Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:48:10 --> Session routines successfully run
DEBUG - 2013-09-23 18:48:10 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:48:10 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:10 --> Controller Class Initialized
DEBUG - 2013-09-23 18:48:10 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:48:10 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:48:10 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:48:10 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:48:10 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:48:10 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:48:10 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:48:10 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:48:10 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:48:10 --> Final output sent to browser
DEBUG - 2013-09-23 18:48:10 --> Total execution time: 0.0245
DEBUG - 2013-09-23 18:48:14 --> Config Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:48:14 --> URI Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Router Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Output Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Security Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Input Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:48:14 --> Language Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Loader Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:48:14 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:48:14 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Session Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:48:14 --> Session routines successfully run
DEBUG - 2013-09-23 18:48:14 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:48:14 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:14 --> Controller Class Initialized
DEBUG - 2013-09-23 18:48:14 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:48:14 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:48:14 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:48:14 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:48:14 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:48:14 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:48:14 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:48:14 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:48:14 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:48:14 --> Final output sent to browser
DEBUG - 2013-09-23 18:48:14 --> Total execution time: 0.0290
DEBUG - 2013-09-23 18:48:17 --> Config Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:48:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:48:17 --> URI Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Router Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Output Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Security Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Input Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:48:17 --> Language Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Loader Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:48:17 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:48:17 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Session Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:48:17 --> Session routines successfully run
DEBUG - 2013-09-23 18:48:17 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:48:17 --> Model Class Initialized
DEBUG - 2013-09-23 18:48:17 --> Controller Class Initialized
DEBUG - 2013-09-23 18:48:17 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:48:17 --> Final output sent to browser
DEBUG - 2013-09-23 18:48:17 --> Total execution time: 0.0431
DEBUG - 2013-09-23 18:56:56 --> Config Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:56:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:56:56 --> URI Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Router Class Initialized
DEBUG - 2013-09-23 18:56:56 --> No URI present. Default controller set.
DEBUG - 2013-09-23 18:56:56 --> Output Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Security Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Input Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:56:56 --> Language Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Loader Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:56:56 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:56:56 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Session Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:56:56 --> Session routines successfully run
DEBUG - 2013-09-23 18:56:56 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:56:56 --> Model Class Initialized
DEBUG - 2013-09-23 18:56:56 --> Controller Class Initialized
DEBUG - 2013-09-23 18:56:56 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:56:56 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:56:56 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 18:56:56 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:56:56 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:56:56 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:56:56 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 18:56:56 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 18:56:56 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:56:56 --> Final output sent to browser
DEBUG - 2013-09-23 18:56:56 --> Total execution time: 0.0243
DEBUG - 2013-09-23 18:57:16 --> Config Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:57:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:57:16 --> URI Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Router Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Output Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Security Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Input Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:57:16 --> Language Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Loader Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:57:16 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:57:16 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Session Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:57:16 --> Session routines successfully run
DEBUG - 2013-09-23 18:57:16 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:57:16 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:16 --> Controller Class Initialized
DEBUG - 2013-09-23 18:57:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 18:57:16 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 18:57:16 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 18:57:16 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 18:57:16 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 18:57:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 18:57:16 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 18:57:16 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 18:57:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 18:57:16 --> Final output sent to browser
DEBUG - 2013-09-23 18:57:16 --> Total execution time: 0.0251
DEBUG - 2013-09-23 18:57:20 --> Config Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:57:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:57:20 --> URI Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Router Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Output Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Security Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Input Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:57:20 --> Language Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Loader Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:57:20 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:57:20 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Session Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:57:20 --> Session routines successfully run
DEBUG - 2013-09-23 18:57:20 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:57:20 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:20 --> Controller Class Initialized
DEBUG - 2013-09-23 18:57:20 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:57:20 --> Final output sent to browser
DEBUG - 2013-09-23 18:57:20 --> Total execution time: 0.0972
DEBUG - 2013-09-23 18:57:26 --> Config Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Hooks Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Utf8 Class Initialized
DEBUG - 2013-09-23 18:57:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 18:57:26 --> URI Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Router Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Output Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Security Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Input Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 18:57:26 --> Language Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Loader Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 18:57:26 --> Helper loaded: url_helper
DEBUG - 2013-09-23 18:57:26 --> Database Driver Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Session Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Helper loaded: string_helper
DEBUG - 2013-09-23 18:57:26 --> Session routines successfully run
DEBUG - 2013-09-23 18:57:26 --> Pagination Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 18:57:26 --> Model Class Initialized
DEBUG - 2013-09-23 18:57:26 --> Controller Class Initialized
DEBUG - 2013-09-23 18:57:26 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 18:57:26 --> Final output sent to browser
DEBUG - 2013-09-23 18:57:26 --> Total execution time: 0.1315
DEBUG - 2013-09-23 19:08:16 --> Config Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Hooks Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Utf8 Class Initialized
DEBUG - 2013-09-23 19:08:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 19:08:16 --> URI Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Router Class Initialized
DEBUG - 2013-09-23 19:08:16 --> No URI present. Default controller set.
DEBUG - 2013-09-23 19:08:16 --> Output Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Security Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Input Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 19:08:16 --> Language Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Loader Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 19:08:16 --> Helper loaded: url_helper
DEBUG - 2013-09-23 19:08:16 --> Database Driver Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Session Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Helper loaded: string_helper
DEBUG - 2013-09-23 19:08:16 --> Session routines successfully run
DEBUG - 2013-09-23 19:08:16 --> Pagination Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 19:08:16 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:16 --> Controller Class Initialized
DEBUG - 2013-09-23 19:08:16 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 19:08:16 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 19:08:16 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 19:08:16 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 19:08:16 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 19:08:16 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 19:08:16 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 19:08:16 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 19:08:16 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 19:08:16 --> Final output sent to browser
DEBUG - 2013-09-23 19:08:16 --> Total execution time: 0.0516
DEBUG - 2013-09-23 19:08:19 --> Config Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Hooks Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Utf8 Class Initialized
DEBUG - 2013-09-23 19:08:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 19:08:19 --> URI Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Router Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Output Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Security Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Input Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 19:08:19 --> Language Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Loader Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 19:08:19 --> Helper loaded: url_helper
DEBUG - 2013-09-23 19:08:19 --> Database Driver Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Session Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Helper loaded: string_helper
DEBUG - 2013-09-23 19:08:19 --> Session routines successfully run
DEBUG - 2013-09-23 19:08:19 --> Pagination Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 19:08:19 --> Model Class Initialized
DEBUG - 2013-09-23 19:08:19 --> Controller Class Initialized
DEBUG - 2013-09-23 19:08:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 19:08:19 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 19:08:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 19:08:19 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 19:08:19 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 19:08:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 19:08:19 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 19:08:19 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 19:08:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 19:08:19 --> Final output sent to browser
DEBUG - 2013-09-23 19:08:19 --> Total execution time: 0.0361
DEBUG - 2013-09-23 19:18:59 --> Config Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Hooks Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Utf8 Class Initialized
DEBUG - 2013-09-23 19:18:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 19:18:59 --> URI Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Router Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Output Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Security Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Input Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 19:18:59 --> Language Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Loader Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 19:18:59 --> Helper loaded: url_helper
DEBUG - 2013-09-23 19:18:59 --> Database Driver Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Session Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Helper loaded: string_helper
DEBUG - 2013-09-23 19:18:59 --> Session routines successfully run
DEBUG - 2013-09-23 19:18:59 --> Pagination Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Model Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Model Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 19:18:59 --> Model Class Initialized
DEBUG - 2013-09-23 19:18:59 --> Controller Class Initialized
DEBUG - 2013-09-23 19:18:59 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 19:18:59 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 19:18:59 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 19:18:59 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 19:18:59 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 19:18:59 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 19:18:59 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 19:18:59 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 19:18:59 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 19:18:59 --> Final output sent to browser
DEBUG - 2013-09-23 19:18:59 --> Total execution time: 0.0242
DEBUG - 2013-09-23 23:37:19 --> Config Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Hooks Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Utf8 Class Initialized
DEBUG - 2013-09-23 23:37:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 23:37:19 --> URI Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Router Class Initialized
DEBUG - 2013-09-23 23:37:19 --> No URI present. Default controller set.
DEBUG - 2013-09-23 23:37:19 --> Output Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Security Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Input Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 23:37:19 --> Language Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Loader Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 23:37:19 --> Helper loaded: url_helper
DEBUG - 2013-09-23 23:37:19 --> Database Driver Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Session Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Helper loaded: string_helper
DEBUG - 2013-09-23 23:37:19 --> A session cookie was not found.
DEBUG - 2013-09-23 23:37:19 --> Session routines successfully run
DEBUG - 2013-09-23 23:37:19 --> Pagination Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 23:37:19 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Controller Class Initialized
DEBUG - 2013-09-23 23:37:19 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 23:37:19 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 23:37:19 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 23:37:19 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 23:37:19 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 23:37:19 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 23:37:19 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 23:37:19 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 23:37:19 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 23:37:19 --> Final output sent to browser
DEBUG - 2013-09-23 23:37:19 --> Total execution time: 0.0285
DEBUG - 2013-09-23 23:37:19 --> Config Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Hooks Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Utf8 Class Initialized
DEBUG - 2013-09-23 23:37:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 23:37:19 --> URI Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Router Class Initialized
DEBUG - 2013-09-23 23:37:19 --> No URI present. Default controller set.
DEBUG - 2013-09-23 23:37:19 --> Output Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Security Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Input Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 23:37:19 --> Language Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Loader Class Initialized
DEBUG - 2013-09-23 23:37:19 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 23:37:19 --> Helper loaded: url_helper
DEBUG - 2013-09-23 23:37:20 --> Database Driver Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Session Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Helper loaded: string_helper
DEBUG - 2013-09-23 23:37:20 --> A session cookie was not found.
DEBUG - 2013-09-23 23:37:20 --> Session routines successfully run
DEBUG - 2013-09-23 23:37:20 --> Pagination Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 23:37:20 --> Model Class Initialized
DEBUG - 2013-09-23 23:37:20 --> Controller Class Initialized
DEBUG - 2013-09-23 23:37:20 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 23:37:20 --> Severity: Notice  --> Undefined index: nosotros /home/liposerv/public_html/ispade/appweb/views/menu.php 31
ERROR - 2013-09-23 23:37:20 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 23:37:20 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 23:37:20 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 23:37:20 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 23:37:20 --> File loaded: appweb/views/carrusel.php
DEBUG - 2013-09-23 23:37:20 --> File loaded: appweb/views/articles_home.php
DEBUG - 2013-09-23 23:37:20 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 23:37:20 --> Final output sent to browser
DEBUG - 2013-09-23 23:37:20 --> Total execution time: 0.0247
DEBUG - 2013-09-23 23:50:27 --> Config Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Hooks Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Utf8 Class Initialized
DEBUG - 2013-09-23 23:50:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 23:50:27 --> URI Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Router Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Output Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Security Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Input Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 23:50:27 --> Language Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Loader Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 23:50:27 --> Helper loaded: url_helper
DEBUG - 2013-09-23 23:50:27 --> Database Driver Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Session Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Helper loaded: string_helper
DEBUG - 2013-09-23 23:50:27 --> Session routines successfully run
DEBUG - 2013-09-23 23:50:27 --> Pagination Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Model Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Model Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 23:50:27 --> Model Class Initialized
DEBUG - 2013-09-23 23:50:27 --> Controller Class Initialized
DEBUG - 2013-09-23 23:50:27 --> File loaded: appweb/views/header.php
ERROR - 2013-09-23 23:50:27 --> Severity: Notice  --> Undefined index: home /home/liposerv/public_html/ispade/appweb/views/menu.php 30
ERROR - 2013-09-23 23:50:27 --> Severity: Notice  --> Undefined index: noticias /home/liposerv/public_html/ispade/appweb/views/menu.php 32
ERROR - 2013-09-23 23:50:27 --> Severity: Notice  --> Undefined index: servicios /home/liposerv/public_html/ispade/appweb/views/menu.php 33
ERROR - 2013-09-23 23:50:27 --> Severity: Notice  --> Undefined index: contactos /home/liposerv/public_html/ispade/appweb/views/menu.php 34
DEBUG - 2013-09-23 23:50:27 --> File loaded: appweb/views/menu.php
DEBUG - 2013-09-23 23:50:27 --> File loaded: appweb/views/lateral_menu.php
DEBUG - 2013-09-23 23:50:27 --> File loaded: appweb/views/presentation.php
DEBUG - 2013-09-23 23:50:27 --> File loaded: appweb/views/foot.php
DEBUG - 2013-09-23 23:50:27 --> Final output sent to browser
DEBUG - 2013-09-23 23:50:27 --> Total execution time: 0.0278
DEBUG - 2013-09-23 23:53:40 --> Config Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Hooks Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Utf8 Class Initialized
DEBUG - 2013-09-23 23:53:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-23 23:53:40 --> URI Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Router Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Output Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Security Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Input Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-23 23:53:40 --> Language Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Loader Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Config file loaded: appweb/config/config.php
DEBUG - 2013-09-23 23:53:40 --> Helper loaded: url_helper
DEBUG - 2013-09-23 23:53:40 --> Database Driver Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Session Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Helper loaded: string_helper
DEBUG - 2013-09-23 23:53:40 --> Session routines successfully run
DEBUG - 2013-09-23 23:53:40 --> Pagination Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Model Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Model Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2013-09-23 23:53:40 --> Model Class Initialized
DEBUG - 2013-09-23 23:53:40 --> Controller Class Initialized
DEBUG - 2013-09-23 23:53:40 --> File loaded: appweb/views/modal.php
DEBUG - 2013-09-23 23:53:40 --> Final output sent to browser
DEBUG - 2013-09-23 23:53:40 --> Total execution time: 0.0529
